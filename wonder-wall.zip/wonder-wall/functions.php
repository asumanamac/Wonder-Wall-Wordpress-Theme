<?php
// Theme Version
define( 'WONDER_WALL_THEME_VERSION', '1.0' );
define( 'WONDER_WALL_THEME_URL', get_template_directory());
define( 'WONDER_WALL_THEME_ADMIN_URL', get_template_directory_uri());

require(WONDER_WALL_THEME_URL . '/includes/plugins/register-plugins.php');
require(WONDER_WALL_THEME_URL. '/includes/classes/header-content.php');
require(WONDER_WALL_THEME_URL . '/includes/classes/wonder-wall-general.php');
require(WONDER_WALL_THEME_URL . '/includes/classes/wonder-wall-metabox.php');
require(WONDER_WALL_THEME_URL . '/includes/widgets/widgets.php');
require(WONDER_WALL_THEME_URL. '/includes/admin/customizer.php');
require(WONDER_WALL_THEME_URL. '/includes/menu.php');
require(WONDER_WALL_THEME_URL. '/includes/css-output.php');
require(WONDER_WALL_THEME_URL. '/includes/demo-importer.php');


add_filter('woocommerce_get_image_size_thumbnail', function($size) {
    return array(
        'width' => 600,
        'height' => 600,
        'crop' => 1,
    );
});



add_action( 'init', function() {
    if ( function_exists( 'as_unschedule_all_actions' ) ) {
        as_unschedule_all_actions( 'your_hook_name' );
    }
});


function theme_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'theme_woocommerce_support');


// Fiyatın Altına Ekstra Bilgi Ekle
add_action('woocommerce_single_product_summary', 'custom_info_after_price', 15);
function custom_info_after_price() {
    echo '<p class="custom-info">Free shipping on all orders over $50!</p>';
}


add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );



function custom_woocommerce_image_sizes() {
    // Ana ürün görseli boyutunu ayarlar
    add_image_size('woocommerce_single', 600, 800, true); // 600x800 boyutunda ve kırpılmış
    update_option('woocommerce_single_image_width', 600); // Ana resim genişliği

    // Galeri küçük resimlerini ayarlar
    add_image_size('woocommerce_thumbnail', 200, 300, true); // 200x300 boyutunda ve kırpılmış
    // update_option('woocommerce_thumbnail_image_width', 200); // Thumbnail genişliği
}
add_action('after_setup_theme', 'custom_woocommerce_image_sizes');




// Tüm içerik kapsayan div'inizi eklemek için
add_action('woocommerce_before_single_product', 'custom_shop_wrapper_start', 5);
function custom_shop_wrapper_start() {
    echo '<div class="custom-shop-wrapper" style="background-color: #f9f5f1; padding: 20px;">';
}

add_action('woocommerce_after_single_product', 'custom_shop_wrapper_end', 50);
function custom_shop_wrapper_end() {
    echo '</div>';
}

// Ürün başlığını farklı bir stil ile eklemek için
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
add_action('woocommerce_single_product_summary', 'custom_product_title', 5);
function custom_product_title() {
    echo '<h1>' . get_the_title() . '</h1>';
}



add_action('wp_enqueue_scripts', 'custom_shop_styles');
function custom_shop_styles() {
    wp_enqueue_style('custom-shop-style', get_stylesheet_directory_uri() . '/custom-shop-style.css');
}



// WooCommerce ürün sayfasında meta bilgilerinin düzenlenmesi
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
add_action('woocommerce_single_product_summary', 'custom_woocommerce_product_meta', 40);

function custom_woocommerce_product_meta() {
    global $product;

    echo '<div class="custom-product-meta">';
    
    // SKU bilgisi
    if ($product->get_sku()) {
        echo '<p class="sku">SKU: <span>' . $product->get_sku() . '</span></p>';
    }
    
    // Kategori bilgisi
    echo '<p class="category">Category: ' . wc_get_product_category_list($product->get_id(), ', ', '<span>', '</span>') . '</p>';
    
    // Etiket bilgisi
    echo '<p class="tags">Tags: ' . wc_get_product_tag_list($product->get_id(), ', ', '<span>', '</span>') . '</p>';

    echo '</div>';
}



// WooCommerce ürün detay sayfasına Additional Information sekmesini ekleyin
add_filter( 'woocommerce_product_tabs', 'add_additional_info_tab' );

function add_additional_info_tab( $tabs ) {
    // 'additional_information' sekmesini aktif hale getirin
    $tabs['additional_information'] = array(
        'title'    => __( 'Additional Information', 'woocommerce' ),
        'priority' => 20, // Sekmenin sırasını belirler
        'callback' => 'woocommerce_product_additional_information_tab'
    );
    return $tabs;
}



// Özel alan ekle
add_action( 'woocommerce_product_options_general_product_data', 'custom_additional_info_field' );

function custom_additional_info_field() {
    woocommerce_wp_text_input( array(
        'id'          => '_custom_additional_info',
        'label'       => __( 'Custom Additional Info', 'woocommerce' ),
        'description' => __( 'Bu alan Additional Information sekmesinde gösterilecektir.', 'woocommerce' ),
        'desc_tip'    => true,
    ) );
}

// Özel alanı kaydet
add_action( 'woocommerce_process_product_meta', 'save_custom_additional_info_field' );

function save_custom_additional_info_field( $post_id ) {
    $custom_additional_info = isset( $_POST['_custom_additional_info'] ) ? sanitize_text_field( $_POST['_custom_additional_info'] ) : '';
    update_post_meta( $post_id, '_custom_additional_info', $custom_additional_info );
}

// Özel alanı Additional Information sekmesinde göster
add_filter( 'woocommerce_product_tabs', 'add_custom_additional_info_tab' );

function add_custom_additional_info_tab( $tabs ) {
    $tabs['additional_information']['callback'] = 'display_custom_additional_info';
    return $tabs;
}

function display_custom_additional_info() {
    global $product;
    $custom_additional_info = get_post_meta( $product->get_id(), '_custom_additional_info', true );

    if ( ! empty( $custom_additional_info ) ) {
        echo '<p>' . esc_html( $custom_additional_info ) . '</p>';
    }
}


add_action('wp', 'theme_woocommerce_elementor_compatibility');
function theme_woocommerce_elementor_compatibility() {
    if (class_exists('WooCommerce')) {
        if (is_product() && class_exists('Elementor\Plugin')) {
            remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
        }
    }
}



$shop_page_id = get_option( 'woocommerce_shop_page_id' ); // Shop sayfası ID'sini al
$shop_container = get_post_meta( $shop_page_id, 'wonder-wall-page-layout', true );

if ( ! empty( $shop_container ) ) {
    $container_class = $shop_container;
} else {
    $container_class = 'container';
}



function enqueue_font_awesome() {
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css' );
}
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );

function add_font_awesome() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'add_font_awesome');


add_action('woocommerce_single_product_summary', 'custom_social_share_buttons_with_icons', 50);
function custom_social_share_buttons_with_icons() {
    global $product;
    $product_url = get_permalink($product->get_id());
    $product_title = get_the_title($product->get_id());
    ?>
    <div class="eb-social-share">
        <p>Share this product:</p>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $product_url; ?>" class="eb-facebook" target="_blank">
            <i class="fa fa-facebook-f"></i>
        </a>
        <a href="https://www.instagram.com/" class="eb-instagram" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="https://twitter.com/intent/tweet?text=<?php echo $product_title; ?>&url=<?php echo $product_url; ?>" class="eb-twitter" target="_blank">
            <i class="fab fa-x"></i>
        </a>
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $product_url; ?>" class="eb-linkedin" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>
        <a href="mailto:?subject=<?php echo $product_title; ?>&body=<?php echo $product_url; ?>" class="eb-mail" target="_blank">
            <i class="fas fa-envelope"></i>
        </a>
        
    </div>
    <?php
}

// "You may also like" metnini "Related products" olarak değiştirmek
add_filter( 'woocommerce_product_related_products_heading', 'change_related_products_text', 10, 1 );

function change_related_products_text( $title ) {
    return 'Related products';  // Buraya istediğiniz metni yazabilirsiniz
}
function enqueue_gsap_with_scrolltrigger() {
    // GSAP Ana Kütüphane
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), null, true);

    // ScrollTrigger Eklentisi
    wp_enqueue_script('gsap-scrolltrigger', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap'), null, true);

    // ScrollToPlugin Eklentisi
    wp_enqueue_script('gsap-scrollto', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollToPlugin.min.js', array('gsap'), null, true);


    wp_enqueue_script('swup', 'https://unpkg.com/swup@3/dist/swup.min.js', array(), null, true);

    // Swup Animasyon Scriptini Yükle
    wp_enqueue_script(
        'swup-animation-js',
        get_template_directory_uri() . '/includes/assets/js/swup-animation.js',
        array('swup'), // Swup bağımlılığı ekleniyor
        '1.0',
        true
    );

}
add_action('wp_enqueue_scripts', 'enqueue_gsap_with_scrolltrigger');





function my_theme_scripts() {
    wp_enqueue_script( 'main-animation-js', get_template_directory_uri() . '/includes/assets/js/main-animation.js', array( 'jquery' ), '1.0', true );

    // Kirki ayarını al
    $animation_enabled = get_theme_mod( 'animation-switcher', 'on' ); // Varsayılan "1" (Açık)

    // Değeri kontrol et ve doğru şekilde aktar
    wp_localize_script( 'main-animation-js', 'animationSettings', [
        'enabled' => $animation_enabled == 'on' ? true : false, // Değer "1" ise açık
    ]);
}
add_action( 'wp_enqueue_scripts', 'my_theme_scripts' );

$animation_enabled2 = get_theme_mod( 'animation-switcher' ); // Varsayılan "1" (Açık)


// Yeni boyutu medya yükleme ekranında görünür hale getirme
function custom_image_sizes($sizes) {
    return array_merge($sizes, [
        'custom-size' => __('Custom Size 300x300'),
    ]);
}
add_filter('image_size_names_choose', 'custom_image_sizes');

remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);

function allow_svg_uploads( $mimes ) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter( 'upload_mimes', 'allow_svg_uploads' );


?>