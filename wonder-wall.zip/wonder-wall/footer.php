<?php

$footer_switcher = get_theme_mod('footer on/off','on');
$footer_bg_image = get_theme_mod('bg-footer-image');
$footer_copyright_text = get_theme_mod('footer-copyright-text');
$newsletter_title_switcher = get_theme_mod('newsletter_title on/off', 'on');
$newsletter_title = get_theme_mod( 'wonder_wall_footer_newsletter_title' );
$newsletter_subtitle_switcher = get_theme_mod('newsletter_subtitle on/off', 'on');
$newsletter_subtitle = get_theme_mod( 'wonder_wall_footer_newsletter_subtitle' );
$newsletter_form_id = get_theme_mod( 'wonder_wall_footer_newsletter_form_id' );

$back_top = get_theme_mod('back-top-switcher', 'on');

$footer_bottom_area = get_theme_mod('footer-bottom-area on/off', 'on');
$footer_botton_area_copyright_text = get_theme_mod('footer-bottom-area-copyright-text');
$footer_bottom_area_social_media = get_theme_mod('footer-social-media on/off','on');



    $output = '';

    if($footer_switcher == 'on') {
        if(!empty($footer_bg_image)) {
            $output .= '<footer class="eb-footer eb-style-1" style="background: url('. esc_url($footer_bg_image) .') no-repeat;">';
        }
        else {
            $output .= '<footer class="eb-footer eb-style-1">';
                $output .= '<div class="eb-footer-inner">';
                $output .= '<div class="container">';
                    $output .= '<div class="eb-footer-newsletter">';
                        if($newsletter_title_switcher == 'on' ) {
                            $output .= '<div class="eb-footer-heading">';
                                if( $newsletter_title_switcher == 'on' and !empty(esc_attr($newsletter_title))) {
                                    $output .= '<div class="eb-title">'. esc_attr($newsletter_title) .'</div>';
                                }
                                if( $newsletter_subtitle_switcher == 'on' and !empty(esc_attr($newsletter_subtitle))) {
                                    $output .= '<div class="eb-text">'. esc_attr($newsletter_subtitle) .'</div>';
                                }
                            $output .= '</div>';
                        }
                        if( !empty( $newsletter_form_id ) ) {
                            $output .= '<div class="eb-form-wrapper">';
                                $output .= do_shortcode( '[mc4wp_form id="' . esc_attr( $newsletter_form_id ) . '"]' );
                            $output .= '</div>';
                        }
                    $output .= '</div>';
                    $output .= '<div class="eb-footer-bottom">';
                        $output .= '<div class="eb-footer-item-left eb-footer-widget-logo">';
                            if ( is_active_sidebar( 'sidebar-footer1')) {
                                $output .= wonder_wall_get_sidebar( $sidebar = "sidebar-footer1" );
                            }
                            if(!empty($footer_copyright_text)) {
                                $output .= '<div class="eb-footer-copyright">';
                                    $output .= wpautop( $footer_copyright_text );
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                        $output .= '<div class="eb-footer-item-right">';
                            $output .= '<div class="eb-links-inner">';
                                $output .= '<div class="eb-links-widget">';
                                    if ( is_active_sidebar( 'sidebar-footer2')) {
                                        $output .= wonder_wall_get_sidebar( $sidebar = "sidebar-footer2" );
                                    }
                                $output .= '</div>';
                                $output .= '<div class="eb-links-widget">';
                                    if ( is_active_sidebar( 'sidebar-footer3')) {
                                        $output .= wonder_wall_get_sidebar( $sidebar = "sidebar-footer3" );
                                    }
                                $output .= '</div>';
                            $output .= '</div>';
                            if (get_theme_mod( 'footer-brand-logo on/off', 'on' ) == true ) :
                                $output .= '<div class="eb-footer-logo-section">';
                                    $brand_logos = get_theme_mod( 'repeater_footer_setting'); 
                                    foreach ( $brand_logos as $key => $value) :
                                        $output .= '<a href="'. esc_url($value['brand_logo_link']) .'" target="_blank"><img src="'. esc_url($value['brand_logo_image']) .'"></a>';
                                    endforeach; 
                                $output .= '</div>';
                            endif;
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</div>';
                if($footer_bottom_area == 'on') {
                    $output .= '<div class="eb-footer-bottom-area">';
                    $output .= '<div class="container">';
                        $output .= '<div class="eb-footer-bottom-area-inner">';
                            if( !empty($footer_botton_area_copyright_text) ) {
                            $output .= '<div class="eb-footer-bottom-copyright">';
                                    $output .= wpautop( $footer_botton_area_copyright_text );
                                $output .= '</div>';
                            }
                            if($footer_bottom_area_social_media == 'on') {
                                $social_arrays  = get_theme_mod('social_repeater_setting');
                                $output .= '<div class="eb-item eb-footer-social">';
                                    if( !empty($social_media_text) ) {
                                        $output .= '<div class="eb-footer-social-title">'. esc_attr($social_media_text) .'</div>';
                                    }
                                    $output .= '<ul class="eb-social">';
                                    foreach ($social_arrays as $key => $value) : 
                                        $output .= '<li><a href="'. esc_url($value['link_url']) .'" target = '. esc_attr($value['link_target']).'>';
                                            if($value['select'] == 'facebook') {
                                                $output .= '<span><i class="fa-brands fa-'. esc_attr($value['select']).'-f"></i></span>';
                                            } elseif($value['select'] == 'twitter') {
                                                $output .= '<span><i class="fa-brands fa-x"></i></span>';
                                            }
                                            else {
                                                $output .= '<span><i class="fa-brands fa-'. esc_attr($value['select']).'"></i></span>';
                                            }
                                        $output .='</a></li>';
                                    endforeach;
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</div>';
                }
            $output .= '</div>';
        }
        if($back_top== 'on') {
            $output .= '<div id="back-to-top" style="display: none;">';
			$output .= '<a href="#top">↑<a>';
            $output .= '</div>';
        }
        $output .= '</footer>';
    
        echo $output;
    }

    wp_footer(); ?>
    

	</body>
</html>


