<?php
/*======
*
* Merlin Integrations
*
======*/

	require_once get_parent_theme_file_path( '/includes/merlin/vendor/autoload.php' );
	require_once get_parent_theme_file_path( '/includes/merlin/class-merlin.php' );
	require_once get_parent_theme_file_path( '/includes/merlin/merlin-config.php' );




/*======
*
* Demo Importer
*
======*/
if( !function_exists( 'wonder_wall_demo_importer' ) ) {

	function wonder_wall_demo_importer() {

		return array(
			array(
				'import_file_name' => esc_html__( 'Full Demo Content', 'wonder-wall' ),
				'local_import_file' => get_parent_theme_file_path( '/includes/merlin/demo-content/demo-content.xml' ),
				'local_import_widget_file' => get_parent_theme_file_path( '/includes/merlin/demo-content/widgets.wie' ),
				'local_import_customizer_file' => get_parent_theme_file_path( '/includes/merlin/demo-content/customizer.dat' ),
				'preview_url' => esc_url( 'https://themes.asumanamac.com/wonder-wall' ),
			),
		);

	}
	add_filter( 'merlin_import_files', 'wonder_wall_demo_importer' );

}



/*======
*
* Demo Settings
*
======*/
if( !function_exists( 'wonder_wall_demo_settings' ) ) {

	function wonder_wall_demo_settings() {

		/*====== Menu Settings ======*/
		$main_left_menu = get_term_by( 'name', 'Main Menu Left', 'nav_menu' );
		$main_right_menu = get_term_by( 'name', 'Main Menu Right', 'nav_menu' );

		$mobile = get_term_by( 'name', 'Mobile Menu Right', 'nav_menu' );
		$footer_menu = get_term_by( 'name', 'Footer Menu', 'nav_menu' );

		set_theme_mod(
			'nav_menu_locations', array(
				'primary-left' => $main_menu->term_id,
				'primary-right' => $mobile->term_id,
				'footer-menu' => $footer_menu->term_id,
				'mobile' => $footer_menu->term_id,

			)
		);

		/*====== Homepage Settings ======*/
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id = get_page_by_title( 'Blog' );

		if( !empty( $front_page_id ) ) {

			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $front_page_id->ID );

		}

		if( !empty( $blog_page_id ) ) {

			update_option( 'page_for_posts', $blog_page_id->ID );

		}

		/*====== Elementor Settings ======*/
		if( did_action( 'elementor/loaded' ) ) {

			update_option( 'elementor_disable_color_schemes', 'yes' );
			update_option( 'elementor_disable_typography_schemes', 'yes' );
			update_option( 'elementor_global_image_lightbox', 'yes' );

		}

	}
	add_action( 'merlin_after_all_import', 'wonder_wall_demo_settings' );

}