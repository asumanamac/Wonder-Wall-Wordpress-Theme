<?php
	require(WONDER_WALL_THEME_URL. '/includes/widgets/wonder-wall-widget-social.php');
	require(WONDER_WALL_THEME_URL. '/includes/widgets/wonder-wall-widget-contact.php');
	require(WONDER_WALL_THEME_URL. '/includes/widgets/wonder-wall-menu-widget.php');
	require(WONDER_WALL_THEME_URL. '/includes/widgets/wonder-wall-newsletter-widget.php');
	require(WONDER_WALL_THEME_URL. '/includes/widgets/wonder-wall-blog-widget.php');
	require(WONDER_WALL_THEME_URL. '/includes/widgets/wonder-wall-services.php');




?>