<?php
/**
 *
 *
 * @package Wonder Wall Newsletter Widget
 */
class Wonder_Wall_Widget_Newsletter extends WP_Widget {

	function __construct(){
		$widget_ops = array(
			'classname' => 'wonder_wall_widget_newsletter',
		);

		parent::__construct(
			'wonder_wall_widget_Newsletter',
			esc_html__( 'Wonder Wall - Newsletter Widget', 'wonder-wall' ),
			$widget_ops
		);
	}

function widget ($args, $instance ) {

	if( $instance ) {

		$widget_title = ( isset( $instance[ 'widget-title' ] ) ) ? $instance[ 'widget-title' ] : '';
        $subtitle = $instance['subtitle'];
        $title = $instance['title'];
        $button_text = $instance['button-text'];
        $align = esc_attr( $instance['align'] );
        $newsletter_form_id = esc_attr( $instance['newsletter-form-id'] );
        $cookie_text = esc_attr( $instance['cookie-text'] );


    }



	/*====== HTML Output ======*/
             
		echo '<div class="eb-newsletter-widget eb-style-1' . ' eb-align-' . esc_attr( $align ) .'">';
		if ( $widget_title ) {
			echo wp_kses_post($args['before_title']) . esc_attr($widget_title) . $args['after_title'];
		} 
            echo '<div class="eb-newsletter-inner">';
                if(!empty($subtitle)) {
                    echo '<div class="eb-newsletter-subtitle">';
                        echo esc_attr($subtitle);
                    echo '</div>';
                }
                if(!empty($title)) {
                    echo '<div class="eb-newsletter-title">';
                            echo esc_attr($title);
                        echo '</div>';
                    }
                    echo '<div class="eb-form-wrapper">';
					    echo do_shortcode( '[mc4wp_form id="' . esc_attr( $newsletter_form_id ) . '"]' );
           		echo '</div>';
			echo '</div>';
		echo '</div>';
			

	
}

    function form( $instance ) {
        $widget_title = '';
        $align = '';
        $title = '';
        $subtitle = '';
        $newsletter_form_id = '';
        $button_text = '';
        

           if( $instance ) {

            $align = esc_attr( $instance['align'] );
			$widget_title = esc_attr( $instance['widget-title'] );
            $title = esc_attr( $instance['title'] );
            $subtitle = esc_attr( $instance['subtitle'] );
            $newsletter_form_id = esc_attr( $instance['newsletter-form-id'] );
            $button_text = esc_attr( $instance['button-text'] );



        }
		

		
		echo '<p>';
				echo '<label for="' . esc_attr( $this->get_field_id( 'widget-title' ) ) . '">' . esc_html__( 'Widget Title', 'wonder-wall' ) . '</label>';
				echo '<textarea class="widefat" rows="2" id="' . esc_attr( $this->get_field_id( 'widget-title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'widget-title' ) ) . '">' . esc_attr( $widget_title ) . '</textarea>';
			echo '</p>';

			echo '<p>';
				echo '<label for="' . esc_attr( $this->get_field_id( 'align' ) ) . '">' . esc_html__( 'Align', 'wonder-wall' ) . '</label>';
				echo '<select name="' . esc_attr( $this->get_field_name( 'align' ) ) . '" id="' . esc_attr( $this->get_field_id( 'align' ) ) . '" class="widefat">';
					echo '<option value="left"' . ( $align == "left" ? ' selected' : '' ) . '>' . esc_html__( 'Left', 'wonder-wall' ) . '</option>';
					echo '<option value="center"' . ( $align == "center" ? ' selected' : '' ) . '>' . esc_html__( 'Center', 'wonder-wall' ) . '</option>';
					echo '<option value="right"' . ( $align == "right" ? ' selected' : '' ) . '>' . esc_html__( 'Right', 'wonder-wall' ) . '</option>';
				echo '</select>';
			echo '</p>';

			echo '<p>';
				echo '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">' . esc_html__( 'Title', 'wonder-wall' ) . '</label>';
				echo '<textarea class="widefat" rows="2" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '">' . esc_attr( $title ) . '</textarea>';
			echo '</p>';

			echo '<p>';
				echo '<label for="' . esc_attr( $this->get_field_id( 'subtitle' ) ) . '">' . esc_html__( 'Subtitle', 'wonder-wall' ) . '</label>';
				echo '<textarea class="widefat" rows="2" id="' . esc_attr( $this->get_field_id( 'subtitle' ) ) . '" name="' . esc_attr( $this->get_field_name( 'subtitle' ) ) . '">' . esc_attr( $subtitle) . '</textarea>';
			echo '</p>';

			echo '<p>';
				echo '<label for="' . esc_attr( $this->get_field_id( 'newsletter-form-id' ) ) . '">' . esc_html__( 'Newsletter ID', 'wonder-wall' ) . '</label>';
				echo '<textarea class="widefat" rows="2" id="' . esc_attr( $this->get_field_id( 'newsletter-form-id' ) ) . '" name="' . esc_attr( $this->get_field_name( 'newsletter-form-id' ) ) . '">' . esc_attr($newsletter_form_id ) . '</textarea>';
			echo '</p>';

			echo '<p>';
				echo '<label for="' . esc_attr( $this->get_field_id( 'button-text' ) ) . '">' . esc_html__( 'Button Text', 'wonder-wall' ) . '</label>';
				echo '<textarea class="widefat" rows="2" id="' . esc_attr( $this->get_field_id( 'button-text' ) ) . '" name="' . esc_attr( $this->get_field_name( 'button-text' ) ) . '">' . esc_attr( $button_text ) . '</textarea>';
			echo '</p>';
		 }
}
add_action( 'widgets_init', 'wonder_wall_widget_newsletter' );

function wonder_wall_widget_newsletter() {
	register_widget( 'Wonder_Wall_Widget_Newsletter' );
}