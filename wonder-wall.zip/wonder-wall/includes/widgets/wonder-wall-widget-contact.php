<?php
/**
 *
 *
 * @package Wonder Wall Contact Widget
 */
class Wonder_Wall_Widget_Contact extends WP_Widget {

	function __construct(){
		$widget_ops = array(
			'classname' => 'wonder_wall_widget_contact',
		);

		parent::__construct(
			'wonder_wall_widget_contact',
			esc_html__( 'Wonder Wall - Contact Widget', 'wonder-wall' ),
			$widget_ops
		);
	}

function widget ($args, $instance ) {

	$title = $instance['title'];
	$phone = $instance['phone'];
	$email = $instance['email'];
	?>
    <?php if (!empty($title)) {
		
			echo wp_kses_post($args['before_widget']); 
			echo wp_kses_post($args['before_title']) . esc_attr($title) . $args['after_title'];
		}
        ?>


		<div class="eb-footer-contact-widget">
        	<div class="eb-footer-contact-widget-item eb-footer-phone">
                <div class="eb-icon"><i class="fa-solid fa-phone"></i></div>
                <div class="eb-footer-phone"><a href="telno:<?php echo "+".esc_attr($phone) ?>"><?php echo esc_attr($phone) ?></a></div>
            </div>
            <div class="eb-footer-contact-widget-item eb-footer-mail">
                <div class="eb-icon"><i class="fa-solid fa-envelope"></i></div>
                <div class="eb-footer-mail"><a href="mailto:<?php echo esc_attr($email)?>"><?php echo esc_attr($email) ?></a></div>
            </div>
		</div>

	<?php echo wp_kses_post($args['after_widget']);?>
	<?php
}

    function form( $instance ) {
		$title = '';
		$phone = '';
   		$email = '';

		   if( $instance) {
			$title = isset( $instance[ 'title' ] ) ? esc_attr( $instance[ 'title' ] ) : '';
			$phone = isset( $instance[ 'phone' ] ) ? esc_attr( $instance[ 'phone' ] ) : '';
			$email = isset( $instance[ 'email' ] ) ? esc_attr( $instance[ 'email' ] ) : '';
		}
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'linwall' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>


		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php esc_html_e( 'Phone:', 'linwall' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="tel" value="<?php echo esc_attr( $phone ); ?>" />

		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_html_e( 'Email:', 'linwall' ); ?></label>
			<input type="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>"  value="<?php echo esc_attr( $email ); ?>" />

		</p>
		
<?php }
}
add_action( 'widgets_init', 'wonder_wall_widget_contact' );

function wonder_wall_widget_contact() {
	register_widget( 'Wonder_Wall_Widget_Contact' );
}