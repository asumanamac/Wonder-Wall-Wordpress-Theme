<?php
/**
 *
 *
 * @package Wonder Wall Services Widget
 */
class wonder_wall_Services extends WP_Widget {

	function __construct(){
		$widget_ops = array(
			'classname' => 'wonder_wall_widget_services',
		);

		parent::__construct(
			'wonder_wall_widget_services',
			esc_html__( 'Wonder Wall - Services Widget', 'wonder-wall' ),
			$widget_ops
		);
	}

    function widget( $args, $instance ) {
 
        echo $args['before_widget'];

            /*====== Instance ======*/
            if( $instance ) {

                $widget_title = esc_attr( $instance['title'] );
                $post_count = esc_attr( $instance['post-count'] );
                $widget_category = esc_attr( $instance['category'] );
                $exclude_posts = esc_attr( $instance['exclude-posts'] );
                $offset = esc_attr( $instance['offset'] );
                $order = esc_attr( $instance['order'] );
                $order_type = esc_attr( $instance['order-type'] );
                $image = esc_attr( $instance['image'] );
                $date_info = esc_attr( $instance['date-info'] );
                $date_type = esc_attr( $instance['date-type'] );
                $category_info = esc_attr( $instance['category-info'] );
            }

            /*====== Date Info Type ======*/
            $date_info_type = get_theme_mod( 'wonder-wall_blog_date_info_type', 'date-time' );

            /*====== Title ======*/
            if( !empty( $widget_title ) ) {

                echo $args['before_title'];
                    echo esc_attr( $widget_title );
                echo $args['after_title'];

            }

            /*====== Main Query ======*/
            $arg = array(
                'post_type' => 'service',
                'post_status' => 'publish',
                'ignore_sticky_posts' => true,
                'offset' => $offset,
                'posts_per_page' => $post_count,
                'post__not_in' => $exclude_posts,
                'cat' => $widget_category
            );
            
            /*====== Exclude Posts ======*/
            if( !empty( $exclude_posts ) ) {

                $exclude_posts = $exclude_posts;
                $exclude_posts = explode( ',', $exclude_posts );

            }

            /*====== Order & Order By ======*/
            if( !empty( $order ) ) {

                $extra_query = array(
                    'order' => $order,
                );
                $arg = wp_parse_args( $arg, $extra_query );

            }

            if( $order_type == "added-date" ) {

                $order_by = "date";

            } elseif( $order_type == "popular-comment" ) {

                $order_by = "comment_count";

            } elseif( $order_type == "id" ) {

                $order_by = "ID";

            } elseif( $order_type == "title" ) {

                $order_by = "title";

            } elseif( $order_type == "menu-order" ) {

                $order_by = "menu_order";

            } elseif( $order_type == "random" ) {

                $order_by = "rand";

            } elseif( $order_type == "include-ids" ) {

                $order_by = "post__in";

            } elseif( $order_type == "none" ) {

                $order_by = "none";

            }

            if( !empty( $order_by ) ) {

                $extra_query = array(
                    'orderby' => $order_by,
                );
                $arg = wp_parse_args( $arg, $extra_query );

            }

            /*====== HTML Output ======*/
            $wp_query = new WP_Query( $arg );

            if( $wp_query->have_posts() ) {

                echo '<div class="eb-blog-widget eb-style-1 eb-align-left">';
                    echo '<div class="eb-blog-widget-inner">';

                        $i = 0;

                        while ( $wp_query->have_posts() ) {

                            $wp_query->the_post();

                            $i++;

                            echo '<div class="eb-item">';

                                if( $image == "1" ) {

                                    if( has_post_thumbnail() ) {

                                        echo '<div class="eb-image">';
                                            echo '<a href="' . get_the_permalink() . '">';
                                                the_post_thumbnail( 'thumbnail' );
                                            echo '</a>';
                                        echo '</div>';

                                    }

                                }

                                echo '<div class="eb-content">';
                                    if( $date_info == "1" ) {

                                        echo '<div class="eb-date">';
                                            echo '<span>';
            
                                                if( $date_type == "date-time" ) {
            
                                                    echo get_the_time( get_option( 'date_format' ), $post_id );
            
                                                } elseif( $date_type == "human-time" ) {
                                                // echo '<a href="'. get_day_link( get_post_time('Y'), get_post_time('m'), get_post_time('j') ) .'">' . sprintf( esc_html__( '%s Ago', 'wonder-wall' ), human_time_diff( get_the_time( 'U', $post_id ), current_time( 'timestamp' ) ) ) . '</a>';
                                                    echo sprintf( esc_html__( '%s Ago', 'wonder-wall' ), human_time_diff( get_the_time( 'U', $post_id ), current_time( 'timestamp' ) ) );
            
                                                }

                                                if( $category_info == "1" ) {

                                                    echo '<div class="eb-category">';
                                                        echo get_the_category_list( '', '', $post_id );
                                                    echo '</div>';
                        
                                                }
            
                                            echo '</span>';
                                        echo '</div>';
            
                                    }
                                    echo '<div class="eb-title">';
                                        echo '<a href="' . get_the_permalink() . '">' . get_the_title() . '</a>';
                                    echo '</div>';

                                echo '</div>';
                            echo '</div>';

                        }
                        wp_reset_postdata();
                    echo '</div>';
                echo '</div>';

            }


        echo $args['after_widget'];

    }

    function update( $new_instance, $old_instance ) {

        $instance = $old_instance;
        $instance['title'] = esc_attr( $new_instance['title'] );
        $instance['post-count'] = esc_attr( $new_instance['post-count'] );
        $instance['category'] = esc_attr( $new_instance['category'] );
        $instance['exclude-posts'] = esc_attr( $new_instance['exclude-posts'] );
        $instance['offset'] = esc_attr( $new_instance['offset'] );
        $instance['order'] = esc_attr( $new_instance['order'] );
        $instance['order-type'] = esc_attr( $new_instance['order-type'] );
        $instance['image'] = esc_attr( $new_instance['image'] );
        $instance['date-info'] = esc_attr( $new_instance['date-info'] );
        $instance['date-type'] = esc_attr( $new_instance['date-type'] );
        $instance['category-info'] = esc_attr( $new_instance['category-info'] );


        return $instance;

    }

    function form( $instance ) {

        $title = '';
        $post_count = '';
        $category = '';
        $exclude_posts = '';
        $offset = '';
        $order = '';
        $order_type = '';
        $image = '';
        $date_info = '';
        $date_type = '';
        $category_info = '';


        if( $instance ) {

            $title = esc_attr( $instance['title'] );
            $post_count = esc_attr( $instance['post-count'] );
            $category = esc_attr( $instance['category'] );
            $exclude_posts = esc_attr( $instance['exclude-posts'] );
            $offset = esc_attr( $instance['offset'] );
            $order = esc_attr( $instance['order'] );
            $order_type = esc_attr( $instance['order-type'] );
            $image = esc_attr( $instance['image'] );
            $date_info = esc_attr( $instance['date-info'] );
            $date_type = esc_attr( $instance['date-type'] );
            $category_info = esc_attr( $instance['category-info'] );

        }

        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">' . esc_html__( 'Title', 'wonder-wall' ) . '</label>';
            echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '" />';
        echo '</p>';


        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'post-count' ) ) . '">' . esc_html__( 'Post Count', 'wonder-wall' ) . '</label>';
            echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'post-count' ) ) . '" name="' . esc_attr( $this->get_field_name( 'post-count' ) ) . '" type="text" value="' . esc_attr( $post_count ) . '" />';
        echo '</p>';

        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'category' ) ) . '">' . esc_html__( 'Category', 'wonder-wall' ) . '</label>';
            echo '<select name="' . esc_attr( $this->get_field_name( 'category' ) ) . '" id="' . esc_attr( $this->get_field_id( 'category' ) ) . '" class="widefat">';
                echo '<option value="">' . esc_html__( 'All Categories', 'wonder-wall' ) . '</option>';

                 $categories = get_categories( 'child_of=0' );

                 if( !empty( $categories ) ) {

                     foreach( $categories as $cat ) {

                        if( !empty( $cat ) ) {

                            $selected = '';

                            if( $category == $cat->cat_ID ) {

                                $selected = " selected";

                            }

                            echo '<option value="' . esc_attr( $cat->cat_ID ) . '"' . esc_attr( $selected ) . '>' . esc_attr( $cat->cat_name ) . '</option>';
                        }

                     }

                 }

            echo '</select>';
        echo '</p>';

        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'exclude-posts' ) ) . '">' . esc_html__( 'Exclude Posts', 'wonder-wall' ) . '</label>';
            echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'exclude-posts' ) ) . '" name="' . esc_attr( $this->get_field_name( 'exclude-posts' ) ) . '" type="text" value="' . esc_attr( $exclude_posts ) . '" />';
        echo '</p>';

        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'offset' ) ) . '">' . esc_html__( 'Offset', 'wonder-wall' ) . '</label>';
            echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'offset' ) ) . '" name="' . esc_attr( $this->get_field_name( 'offset' ) ) . '" type="text" value="' . esc_attr( $offset ) . '" />';
        echo '</p>';

        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'order' ) ) . '">' . esc_html__( 'Order', 'wonder-wall' ) . '</label>';
            echo '<select name="' . esc_attr( $this->get_field_name( 'order' ) ) . '" id="' . esc_attr( $this->get_field_id( 'order' ) ) . '" class="widefat">';
                echo '<option value="DESC"' . ( $order == "DESC" ? ' selected' : '' ) . '>' . esc_html__( 'DESC', 'wonder-wall' ) . '</option>';
                echo '<option value="ASC"' . ( $order == "ASC" ? ' selected' : '' ) . '>' . esc_html__( 'ASC', 'wonder-wall' ) . '</option>';
            echo '</select>';
        echo '</p>';

        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'order-type' ) ) . '">' . esc_html__( 'Order Type', 'wonder-wall' ) . '</label>';
            echo '<select name="' . esc_attr( $this->get_field_name( 'order-type' ) ) . '" id="' . esc_attr( $this->get_field_id( 'order-type' ) ) . '" class="widefat">';
                echo '<option value="added-date"' . ( $order_type == "added-date" ? ' selected' : '' ) . '>' . esc_html__( 'Added Date', 'wonder-wall' ) . '</option>';
                echo '<option value="popular-comment"' . ( $order_type == "popular-comment" ? ' selected' : '' ) . '>' . esc_html__( 'Popular by Comment', 'wonder-wall' ) . '</option>';
                echo '<option value="id"' . ( $order_type == "id" ? ' selected' : '' ) . '>' . esc_html__( 'ID', 'wonder-wall' ) . '</option>';
                echo '<option value="title"' . ( $order_type == "title" ? ' selected' : '' ) . '>' . esc_html__( 'Title', 'wonder-wall' ) . '</option>';
                echo '<option value="menu-order"' . ( $order_type == "menu-order" ? ' selected' : '' ) . '>' . esc_html__( 'Menu Order', 'wonder-wall' ) . '</option>';
                echo '<option value="random"' . ( $order_type == "random" ? ' selected' : '' ) . '>' . esc_html__( 'Random', 'wonder-wall' ) . '</option>';
                echo '<option value="include-ids"' . ( $order_type == "include-ids" ? ' selected' : '' ) . '>' . esc_html__( 'By Include IDs', 'wonder-wall' ) . '</option>';
                echo '<option value="none"' . ( $order_type == "none" ? ' selected' : '' ) . '>' . esc_html__( 'None', 'wonder-wall' ) . '</option>';
            echo '</select>';
        echo '</p>';

        echo '<p>';
            echo '<input id="' . esc_attr( $this->get_field_id( 'image' ) ) . '" name="' . esc_attr( $this->get_field_name( 'image' ) ) . '" type="checkbox" value="1" ' . checked( esc_attr( $image ), true, false ) . ' />';
            echo '<label for="' . esc_attr( $this->get_field_id( 'image' ) ) . '">' . esc_html__( 'Image', 'wonder-wall' ) . '</label>';
        echo '</p>';

        echo '<p>';
            echo '<input id="' . esc_attr( $this->get_field_id( 'date-info' ) ) . '" name="' . esc_attr( $this->get_field_name( 'date-info' ) ) . '" type="checkbox" value="1" ' . checked( esc_attr( $date_info ), true, false ) . ' />';
            echo '<label for="' . esc_attr( $this->get_field_id( 'date-info' ) ) . '">' . esc_html__( 'Date Info', 'wonder-wall' ) . '</label>';
        echo '</p>';


        echo '<p>';
            echo '<label for="' . esc_attr( $this->get_field_id( 'date-type' ) ) . '">' . esc_html__( 'Date Type', 'wonder-wall' ) . '</label>';
            echo '<select name="' . esc_attr( $this->get_field_name( 'date-type' ) ) . '" id="' . esc_attr( $this->get_field_id( 'date-type' ) ) . '" class="widefat">';
                echo '<option value="date-time"' . ( $date_type == "date-time" ? ' selected' : '' ) . '>' . esc_html__( 'Date Time', 'wonder-wall' ) . '</option>';
                echo '<option value="human-time"' . ( $date_type== "human-time" ? ' selected' : '' ) . '>' . esc_html__( 'Human Time', 'wonder-wall' ) . '</option>';
            echo '</select>';
        echo '</p>';

        echo '<p>';
				echo '<input id="' . esc_attr( $this->get_field_id( 'category-info' ) ) . '" name="' . esc_attr( $this->get_field_name( 'category-info' ) ) . '" type="checkbox" value="1" ' . checked( esc_attr( $category_info ), true, false ) . ' />';
				echo '<label for="' . esc_attr( $this->get_field_id( 'category-info' ) ) . '">' . esc_html__( 'Category Info', 'wonder-wall-core' ) . '</label>';
		echo '</p>';


    }}
add_action( 'widgets_init', 'wonder_wall_widget_services' );

function wonder_wall_widget_services() {
	register_widget( 'wonder_wall_Services' );
}
