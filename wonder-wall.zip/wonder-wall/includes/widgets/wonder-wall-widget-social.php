<?php
/**
 * Custom social widget
 *
 * @package wonder-wall Social Widget
 */

class wonder_wall_Widget_Social extends WP_Widget {

	function __construct(){

		$widget_ops = array(
			'classname' => 'wonder-wall-widget-social', 
			'description' => esc_html__( 'Use this widget to display your social accounts.', 'wonder-wall' ) 
		);

		parent::__construct(
			'wonder-wall-social-widget',
			esc_html__( 'Wonder Wall - Social Widget' , 'wonder-wall' ),
			$widget_ops
		);
	}

	function widget( $args, $instance ) {

		extract( $args );

		// $title = apply_filters( 'widget_title', $instance[ 'title' ] );
		$target = isset( $instance[ 'target' ] ) ? $instance[ 'target' ] : false;
		if ( ! $target ) {
			$target = false;
		}
		$title = ( isset( $instance[ 'title' ] ) ) ? $instance[ 'title' ] : '';
		$facebook = ( isset( $instance[ 'facebook' ] ) ) ? $instance[ 'facebook' ] : '';
		$twitter = ( isset( $instance[ 'twitter' ] ) ) ? $instance[ 'twitter' ] : '';
		$instagram = ( isset( $instance[ 'instagram' ] ) ) ? $instance[ 'instagram' ] : '';
		$pinterest = ( isset( $instance[ 'pinterest' ] ) ) ? $instance[ 'pinterest' ] : '';
		$tiktok = ( isset( $instance[ 'tiktok' ] ) ) ? $instance[ 'tiktok' ] : '';
		$linkedin = ( isset( $instance[ 'linkedin' ] ) ) ? $instance[ 'linkedin' ] : '';


		echo $before_widget;

		?>

		<?php $target = ( $target ) ? 'target="_blank"' : ''; ?>
		<?php if ( $title ) {
				echo wp_kses_post($args['before_title']) . esc_attr($title) . $args['after_title'];
			}
		?>
		<div class="eb-footer-social-widget">
		<ul class="eb-social">
				<?php
		 	if ( $facebook != '' ) : ?>
				<li><a class="facebook" href="<?php echo esc_url( $facebook ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa-brands fa-facebook-f"></i></a></li>
			<?php endif; ?>
			<?php if ( $twitter != '' ) : ?>
				<li><a class="twitter" href="<?php echo esc_url( $twitter ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa-brands fa-x"></i></a></li>
			<?php endif; ?>
			<?php if ( $instagram != '' ) : ?>
				<li><a class="instagram" href="<?php echo esc_url( $instagram ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa-brands fa-instagram"></i></a></li>
			<?php endif; ?>
			<?php if ( $pinterest != '' ) : ?>
				<li><a class="google" href="<?php echo esc_url( $pinterest ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa-brands fa-pinterest"></i></a></li>
			<?php endif; ?>
			<?php if ( $tiktok != '' ) : ?>
				<li><a class="tiktok" href="<?php echo esc_url( $tiktok ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa-brands fa-tiktok"></i></a></li>
			<?php endif; ?>
			<?php if ( $tiktok != '' ) : ?>
				<li><a class="linkedin" href="<?php echo esc_url( $tiktok ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa-brands fa-linkedin"></i></a></li>
			<?php endif; ?>
			</ul>
		</div><!--social-widget-->
		<?php echo wp_kses_post($args['after_widget']);?>
		<?php

	}

	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$instance[ 'title' ] = strip_tags( $new_instance[ 'title' ] );
		$instance[ 'target' ] = isset( $new_instance[ 'target' ] ) ? (bool) $new_instance[ 'target' ] : false;
		$instance[ 'facebook' ] = strip_tags( $new_instance[ 'facebook' ] );
		$instance[ 'twitter' ] = strip_tags( $new_instance[ 'twitter' ] );
		$instance[ 'instagram' ] = strip_tags( $new_instance[ 'instagram' ] );
		$instance[ 'pinterest' ] = strip_tags( $new_instance[ 'pinterest' ] );
		$instance[ 'tiktok' ] = strip_tags( $new_instance[ 'tiktok' ] );
		$instance[ 'linkedin' ] = strip_tags( $new_instance[ 'linkedin' ] );



		return $instance;
	}

	function form( $instance ) {

		if( $instance) {
		$title = isset( $instance[ 'title' ] ) ? esc_attr( $instance[ 'title' ] ) : '';
		$target = isset( $instance[ 'target' ] ) ? (bool) $instance[ 'target' ] : false;
		$facebook = isset( $instance[ 'facebook' ] ) ? esc_attr( $instance[ 'facebook' ] ) : '';
		$twitter = isset( $instance[ 'twitter' ] ) ? esc_attr( $instance[ 'twitter' ] ) : '';
		$instagram = isset( $instance[ 'instagram' ] ) ? esc_attr( $instance[ 'instagram' ] ) : '';
		$pinterest = isset( $instance[ 'pinterest' ] ) ? esc_attr( $instance[ 'pinterest' ] ) : '';
		$pinterest = isset( $instance[ 'tiktok' ] ) ? esc_attr( $instance[ 'tiktok' ] ) : '';
		$linkedin = isset( $instance[ 'linkedin' ] ) ? esc_attr( $instance[ 'linkedin' ] ) : '';

		}


		?>

        <p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			<input class="checkbox" type="checkbox" <?php checked( $target ); ?> id="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'target' ) ); ?>" />
			<label for="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>"><?php esc_html_e( 'Open social links in a new window/tab?', 'wonder-wall' ); ?></label>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>"><?php esc_html_e( 'Facebook URL:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" value="<?php echo esc_attr( $facebook ); ?>">
		</p>


		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>"><?php esc_html_e( 'Twitter URL:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" value="<?php echo esc_attr( $twitter ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>"><?php esc_html_e( 'Instagram URL:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'instagram' ) ); ?>" value="<?php echo esc_attr( $instagram ); ?>">
		</p>


		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>"><?php esc_html_e( 'Pinterest URL:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'pinterest' ) ); ?>" value="<?php echo esc_attr( $pinterest ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'tiktok' ) ); ?>"><?php esc_html_e( 'Tiktok URL:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tiktok' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tiktok' ) ); ?>" value="<?php echo esc_attr( $tiktok ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>"><?php esc_html_e( 'Linkedin URL:', 'wonder-wall' ) ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linkedin' ) ); ?>" value="<?php echo esc_attr( $linkedin); ?>">
		</p>

	<?php
	}

}


add_action( 'widgets_init', 'wonder_wall_social_widget' );

function wonder_wall_social_widget() {
	register_widget( 'wonder_wall_Widget_Social' );
}