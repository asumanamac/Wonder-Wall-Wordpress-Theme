<div class="blog-posts page-main col-md-9">
    <div class="row">
    <?php
        if ( has_post_thumbnail()) {?>
	        <article class="col-md-12 col-sm-12 col-xs-12 post page-post">
                <div class="col-md-11 col-sm-11 col-xs-12 post-detail">
                    <header>
                        <div class="post-category">
                            <ul>
                                <li><a><?php linwall_display_categories();?></a></li>
                            </ul>
                        </div><!--post-category-->
                        <div class="post-title">
                            <?php linwall_title('h1' , get_the_title() , false) ?>
                        </div><!--post-title-->
                        <div class="post-date">
                            <a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j'));  ?>"><?php echo get_the_date(); ?></a>
                        </div><!--post-date-->
                    </header>
                    <div class="post-type-video">
                        <?php
                            linwall_output_single_media(rwmb_meta('video-post-link', get_the_ID())); ?>                        ?>
                    </div><!--post-type-video-->
                    <div class="post-entry">
                        <?php  the_content(); ?>
                    </div><!-- post-entry -->
                    <div class="post-tags">
                        <ul>
                            <?php linwall_display_tags(); ?>
                        </ul>
                    </div><!-- post-tags -->
                    </div><!-- post-detail -->
                <?php if (get_theme_mod( 'sticky-on-off', 'on' ) == true) { ?>
                        <div class="col-md-1 col-sm-1 col-xs-12 post-meta sidebar">
                            <div class="row">
                                <?php echo linwall_post_comment_count(); ?>
                                <div class="post-share">
                                    <?php linwall_post_share(get_the_ID()); ?>
                                 </div><!-- post-share -->
                            </div><!--row-->
                        </div><!--post-meta-->
                    <?php } ?>
                    <?php if (get_theme_mod( 'sticky-on-off', 'on' ) == false) { ?>
                        <div class="col-md-1 col-sm-1 col-xs-12 post-meta">
                            <div class="row">
                                <?php echo linwall_post_comment_count(); ?>
                                <div class="post-share">
                                    <?php linwall_post_share(get_the_ID()); ?>
                                </div><!-- post-share -->
                            </div><!--row-->
                        </div><!--post-meta-->
                    <?php } ?>
                </article><!--page-post-->
            <?php } ?>
        <?php  linwall_post_single_author_bio(); ?>
        <?php  linwall_single_related(get_the_ID()); ?>
        <?php comments_template();?>

    </div><!-- row -->
</div><!-- blog-post -->

<div class="sidebar col-md-3">
    <div class="sidebar-content">
        <?php if (rwmb_meta('single_sidebar', '', get_the_ID()) == '') { 
            dynamic_sidebar('sidebar-single');
            } else {
                dynamic_sidebar(rwmb_meta('single_sidebar', '', get_the_ID()));
            }
        ?>
    </div>
</div>
