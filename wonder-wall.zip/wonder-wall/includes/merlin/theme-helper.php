<?php
/**
 * LICENSE
 *
 * Copyright Gloria Themes. All rights reserved.
 * 
 *
 * DO NOT TOUCH THIS FILE!
 *
 * This file contains license protection.
 * This file is a part of a software product that is licensed and protected by law.
 * Any unauthorized modification of this file may result in legal action.
 * You are not permitted to modify, distribute, or sell this file without proper
 * authorization from the owner of the software product. By continuing to use this file,
 * you are agreeing to the terms of the license agreement. If you have any questions
 * regarding the license agreement, please contact the owner of the software product.
 * Thank you for your cooperation.
 */

/*======
*
* Global Settings
*
======*/
$expiration = time() + 2592000;
$theme_slug = wp_get_theme()->get_template();
$theme_info = wp_get_theme();

if( !empty( $theme_info->parent() ) ) {

	$theme_name = esc_attr( $theme_info->parent()->get( 'Name' ) );

} else {

	$theme_name = esc_attr( $theme_info->get( 'Name' ) );

}



/*======
*
* Theme Dashboard URL
*
======*/
if( !function_exists( 'linwall_nature_theme_dashboard_url' ) ) {

	function linwall_nature_theme_dashboard_url() {

		global $theme_slug;

		$url = esc_url( admin_url( 'admin.php?page=' . esc_attr( $theme_slug ) ) );

		return $url;

	}

}



