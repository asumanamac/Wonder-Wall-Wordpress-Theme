<?php
/**
 *
 * Mysterious Css Output
 *
 */
function wonder_wall_css_output(){

    $wonder_wall_custom_css = '';

    /*============================================================================
      >> HEADER SETTINGS
      ============================================================================
    */
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_topbar_bg_color' ,'.eb-header .eb-topbar', 'background-color', '#EBC6BE', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('header_bg_color' ,'.eb-header .eb-bottom', 'background-color', 'transparent', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('header_logo_color' ,'.eb-header.eb-style-1 .eb-item-group .side-drawer-inner .eb-logo a,.eb-header.eb-style-1 .eb-item-group .eb-item.eb-logo a', 'color', '#C88E84');

    $wonder_wall_custom_css .= wonder_wall_css_echo('header_mobile_menu_bg_color' ,'.eb-header.eb-style-1 .eb-bottom-inner .side-drawer', 'background-color', '#fff', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_mobile_menu_text_color' ,'.eb-header.eb-style-1 .eb-bottom-inner .side-drawer .navigation .navbar-side .navbar-side-item .side-link', 'color', '#000', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_mobile_menu_text_hover_color' ,'.eb-header.eb-style-1 .eb-bottom-inner .side-drawer .navigation .navbar-side .navbar-side-item .side-link:hover,.eb-header.eb-style-1 .eb-item-group .eb-item.eb-mobile-menu ul li a:hover i, .eb-header.eb-style-1 .eb-item-group .eb-item.eb-mobile-menu ul li a:visited:hover i', 'color', '#C88E84', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('header_menu-text-color' ,'.eb-header.eb-style-1 .eb-item-group .eb-item.eb-menu ul li a', 'color', '#2D2E2E');
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_menu_hover_color' ,'.eb-header.eb-style-1 .eb-item-group .eb-item.eb-menu ul li a:hover', 'color', '#C78D84' , '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_sub_menu_background' ,'.eb-header.eb-style-1 .eb-item-group .eb-item.eb-menu ul li.eb-dropdown .eb-dropdown-menu', 'background-color', '#fff', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('header_social_media_color' ,'.eb-header.eb-style-1 .eb-item-group .eb-item.eb-header-social ul li a span i', 'color', '#C88E84');
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_social_media_hover_color' ,'.eb-header.eb-style-1 .eb-item-group .eb-item.eb-header-social ul li a:hover i', 'color', '#C88E84');

    $wonder_wall_custom_css .= wonder_wall_css_echo('header_icon_color' ,'.eb-search svg path,.eb-header .eb-item-right svg path', 'stroke', '#000');
    $wonder_wall_custom_css .= wonder_wall_css_echo('header_icon_hover_color' ,'.eb-search svg:hover path, .eb-header eb-item-right svg:hover path', 'stroke', '#000');

    $wonder_wall_custom_css .= wonder_wall_css_echo('post-title_color_setting' ,'.eb-blog-listing.eb-style-1 .eb-item .eb-content .eb-title a', 'color', '#C88E84');
    $wonder_wall_custom_css .= wonder_wall_css_echo('post-title_hover_color_setting' ,'.eb-blog-listing.eb-style-1 .eb-item .eb-content .eb-title a:hover', 'color', '#D58E77');
    $wonder_wall_custom_css .= wonder_wall_css_echo('post-meta_color_setting' ,'.eb-blog-listing.eb-style-1 .eb-item .eb-content .eb-date a', 'color', '#D58E77');
    $wonder_wall_custom_css .= wonder_wall_css_echo('post-meta_hover_color_setting' ,'.eb-blog-listing.eb-style-1 .eb-item .eb-content .eb-date a:hover', 'color', '#C88E84');
    $wonder_wall_custom_css .= wonder_wall_css_echo('post-button_color_setting' ,'.eb-blog-listing.eb-style-1 .eb-item .eb-content .eb-button a', 'color', '#D58E77');
    $wonder_wall_custom_css .= wonder_wall_css_echo('post-button_hover_color_setting' ,'.eb-blog-listing.eb-style-1 .eb-item .eb-content .eb-button a:hover ', 'color', '#C88E84');

    

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_newsletter-title-color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-newsletter .eb-footer-heading .eb-title', 'color', '#C88E84','!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_newsletter-subtitle-color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-newsletter .eb-footer-heading .eb-text', 'color', '#2D2E2E', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_newsletter-button-bg-color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-newsletter .eb-form-wrapper .eb-form input[type="submit"]', 'background-color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_newsletter-button-bg-hover-color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-newsletter .eb-form-wrapper .eb-form input[type="submit"]:hover', 'background-color', '#fff', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_newsletter-button-text-color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-newsletter .eb-form-wrapper .eb-form input[type="submit"]', 'color', '#fff', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_logo-text-color' ,'.eb-footer.eb-style-1 .eb-footer-logo .eb-footer-logo-title a, .eb-footer.eb-style-1 .eb-footer-logo .eb-footer-logo-subtitle a', 'color', '#C78D84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_logo-copyright-text-color' ,'.eb-footer.eb-style-1 .eb-footer-copyright p', 'color', '#2D2E2E');

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-title' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom .eb-links-inner .eb-links-widget .eb-widget-title', 'color', '#2D2E2E', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-content' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom .eb-links-inner .eb-links-widget ul li a', 'color', '#2D2E2E', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_bottom_copyright_bg_color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom-area', 'background-color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_bottom_copyright_color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom-area p', 'color', '#fff', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_social_media_color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom-area-inner .eb-footer-social ul li a span i', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_social_media_bg_color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom-area-inner .eb-footer-social ul li a', 'background-color', '#F4EFEC', '!important');


     /*============================================================================
      >> FOOTER SETTINGS
      ============================================================================
    */

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_bg-color_setting' ,'footer', 'background-color', '#F4EFEC', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_logo-color' ,'.eb-footer-widget-logo p', 'color', '#111');

    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-title' ,'.eb-footer.eb-style-1 .eb-footer-working-hours-widget .eb-widget-title,.eb-footer.eb-style-1 .eb-links-widget .eb-widget-title', 'color', '#111', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-content' ,'.eb-footer.eb-style-1 .eb-footer-working-hours-widget .eb-footer-working-hours-widget-item ul li,.eb-footer.eb-style-1 .eb-links-widget ul li a,.eb-footer-contact-widget a', 'color', '#111', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-social-color' ,'footer .eb-footer-social-widget ul li a i', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-social-hover-color' ,'footer .eb-footer-social-widget ul li a:hover i', 'color', '#7D4D3D', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_widget-contact-icon-color' ,'.eb-footer-contact-widget .eb-footer-contact-widget-item.eb-footer-phone i, .eb-footer-contact-widget .eb-footer-contact-widget-item.eb-footer-mail i', 'color', '#C88E84', '!important');

   
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_copyright_color' ,'.eb-footer.eb-style-1 .eb-footer-copyright p', 'color', '#2D2E2E' );
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_bottom_copyright_bg_color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom-area', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('footer_bottom_copyright_color' ,'.eb-footer.eb-style-1 .eb-footer-inner .eb-footer-bottom-area p', 'color', '#fff', '!important');


  
    
     /*============================================================================
      >> WIDGET SETTINGS
      ============================================================================
    */

    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar-newsletter-widget-title_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-newsletter-subtitle', 'color', '#111');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar-newsletter-widget-desc_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-newsletter-title', 'color', '#C88E84', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_newsletter_button_bg_color_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-form-wrapper form input[type="submit"]', 'background-color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_newsletter_button_text_color_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-form-wrapper form input[type="submit"]', 'color', '#fff', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_newsletter_button_border_color_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-form-wrapper form input[type="submit"]', 'border-color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_newsletter_button_hover_bg_color_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-form-wrapper form input[type="submit"]:hover', 'background-color', '#ffffff00', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_newsletter_button_hover_text_color_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-form-wrapper form input[type="submit"]:hover', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_newsletter_button_hover_border_color_setting' ,'.eb-newsletter-widget.eb-style-1 .eb-form-wrapper form input[type="submit"]:hover', 'border-color', '#C88E84', '!important');


    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_social_color_setting' ,'.eb-footer-social-widget ul li a i, .eb-footer-contact-widget .eb-footer-contact-widget-item.eb-footer-phone i, .eb-footer-contact-widget .eb-footer-contact-widget-item.eb-footer-mail i ', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_social_hover_color_setting' ,'.eb-footer-social-widget ul li a:hover i', 'color', '#7D4D3D', '!important');

    
    $wonder_wall_custom_css .= wonder_wall_css_echo('contact_box_icon_color_setting' ,'.eb-footer-contact-widget .eb-footer-contact-widget-item.eb-footer-phone i', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('contact_box_text_color_setting' ,'.eb-footer-contact-widget a', 'color', '#2D2E2E', '!important');

    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_blog_color_setting' ,'.eb-blog-widget.eb-style-1 .eb-blog-widget-inner .eb-item .eb-content .eb-date span', 'color', '#C88E84', '!important');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_blog_title_color_setting' ,'.eb-blog-widget.eb-style-1 .eb-blog-widget-inner .eb-item .eb-content .eb-title a', 'color', '#111');
    $wonder_wall_custom_css .= wonder_wall_css_echo('sidebar_blog_title_hover_color_setting' ,'.eb-blog-widget.eb-style-1 .eb-blog-widget-inner .eb-item .eb-content .eb-title a:hover', 'color', '#C88E84', '!important');

    wp_add_inline_style( 'wonder_wall-custom-style', $wonder_wall_custom_css );
}
add_action( 'wp_enqueue_scripts', 'wonder_wall_css_output');
?>