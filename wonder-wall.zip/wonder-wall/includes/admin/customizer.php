<?php
/**
 * An example file demonstrating how to add all controls.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2017, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       3.0.12
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    return;
}

// Do not proceed if Kirki does not exist.
if ( ! class_exists( 'kirki' ) ) {
    return;
}


/**
 * First of all, add the config.
 *
 */
Kirki::add_config(
    'kirki_demo', array(
        'capability'  => 'edit_theme_options',
        'option_type' => 'theme_mod',
        'transport' => 'refresh'
    )
);

/**
 * A proxy function. Automatically passes-on the config-id.
 *
 * @param array $args The field arguments.
 */
function wonder_wall_add_field( $args ) {
    Kirki::add_field( 'kirki_demo', $args );
}


/*====== Header Settings Section ======*/
new \Kirki\Section(
	'wonder_wall_header_settings',
	[
		'title'       => esc_html__( 'Header General Setttings', 'wonder-wall' ),
		'priority'    => 1,
		'icon' 		  =>  'dashicons-editor-insertmore'
	]
);

/*====== Header Logo Image On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'logo on/off',
		'label'       => esc_html__( 'Logo Image On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Logo Image On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);


/*====== Header Logo Image ======*/
new \Kirki\Field\Image(
	[
		'settings'    => 'logo-image',
		'label'       => esc_html__( 'Wonder Wall Logo', 'wonder-wall' ),
		'description' => esc_html__( 'Logo will be shown here', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default'     => '',
		'choices'     => [
			'save_as' => 'logo-image',
		],
	]
);

/*====== Logo style text ======*/
new \Kirki\Field\Text(
	[
        'type'        => 'text',
        'settings'    => 'header-logo-text',
        'label'       => esc_html__( 'Header Logo Text', 'wonder-wall' ),
        'description' => esc_html__( 'You can write logo text here.', 'wonder-wall' ),
        'section'     => 'wonder_wall_header_settings',
        'default'     => 'Wonder Wall',
	]
);

/*====== Register text ======*/
new \Kirki\Field\Text(
	[
        'type'        => 'text',
        'settings'    => 'header-register-text',
        'label'       => esc_html__( 'Header Register Text', 'wonder-wall' ),
        'description' => esc_html__( 'You can write register text here.', 'wonder-wall' ),
        'section'     => 'wonder_wall_header_settings',
        'default'     => 'Register Text',
	]
);

/*====== Header Search On/Off ======*/
new \Kirki\Field\Toggle(
	[
		'settings'    => 'header-search',
		'label'       => esc_html__( 'Header Search On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Header Search On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default'     => '1',
		
	]
);

/*====== Header Favourite On/Off ======*/
new \Kirki\Field\Toggle(
	[
		'settings'    => 'header-favourite',
		'label'       => esc_html__( 'Header Favourite On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Header Favourite On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default'     => '1',
		
	]
);

/*====== Header Shop On/Off ======*/
new \Kirki\Field\Toggle(
	[
		'settings'    => 'header-shop',
		'label'       => esc_html__( 'Header Shop On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Header Shop On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default'     => '1',
		
	]
);


/*====== Header Sidebar On/Off ======*/
new \Kirki\Field\Toggle(
	[
		'settings'    => 'sidebar on/off',
		'label'       => esc_html__( 'Header Sidebar On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Header Sidebar On/Off', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default'     => '1',
		
	]
);


/*====== Header Absolute On/Off ======*/
new \Kirki\Field\Radio_Buttonset(
	[
		'settings'    => 'header-absolute',
		'label'       => esc_html__( 'Header Absolute On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Header Absolute On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_header_settings',
		'default' => 'default',
			'choices' => array(
				'default' => esc_html__( 'Standard', 'barica-core' ),
				'absolute' => esc_html__( 'Absolute', 'barica-core' ),
			),
		
	]
);


/*====== Page Settings Section ======*/
new \Kirki\Panel(
	'wonder_wall_page_settings',
	[
		'title'       => esc_html__( 'Page Setttings', 'wonder-wall' ),
		'priority'    => 2,
		'icon' 		  =>  'dashicons-admin-page'
	]
);

new \Kirki\Section(
	'page_layout',
	[
		'title'       => esc_html__( 'Page Layout', 'wonder-wall' ),
		'panel'       => 'wonder_wall_page_settings',
		'priority'    => 150,
	]
);

new \Kirki\Field\Radio_Buttonset(

	[
		'settings'    => 'wonder_wall_page_layout',
		'label'       => esc_html__( 'Page Layout', 'wonder-wall' ),
		'section'     =>'page_layout',
		'default'     => 'container',
		'choices'     => [
			'container'  => esc_html__( 'Container', 'wonder-wall' ),
			'full-container' => esc_html__( 'Full Container', 'wonder-wall' ),
		],
	]
);

new \Kirki\Section(
	'page_404',
	[
		'title'       => esc_html__( '404 Page', 'wonder-wall' ),
		'panel'       => 'wonder_wall_page_settings',
		'priority'    => 160,
	]
);

/*====== 404 Page Background Image ======*/
new \Kirki\Field\Background(
	[
		'settings'    => 'background_setting',
		'label'       => esc_html__( '404 Page Background ', 'wonder-wall' ),
		'section'     =>'page_404',
		'default'     => [
			'background-color'      => '#FFF7F4',
			'background-image'      => '',
			'background-repeat'     => 'repeat',
			'background-position'   => 'center center',
			'background-size'       => 'cover',
			'background-attachment' => 'scroll',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => 'body.error404',
			],
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'title_switch_404',
		'label'       => esc_html__( 'Title On/Off', 'wonder-wall' ),
		'section'     =>'page_404',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);

new \Kirki\Field\Text(
	[
		'settings' => 'title_404',
		'label'    => esc_html__( '404 Page Title', 'wonder-wall' ),
		'section'     =>'page_404',
		'priority' => 10,
		'active_callback' => [
			[
				'setting'  => 'title_switch_404',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'desc_switch_404',
		'label'       => esc_html__( 'Description On/Off', 'wonder-wall' ),
		'section'     =>'page_404',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);


new \Kirki\Field\Textarea(
	[
		'settings'    => 'desc_404',
		'label'       => esc_html__( '404 Page Description', 'wonder-wall' ),
		'section'     =>'page_404',
		'active_callback' => [
			[
				'setting'  => 'desc_switch_404',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'button_switch_404',
		'label'       => esc_html__( 'Button On/Off', 'wonder-wall' ),
		'section'     =>'page_404',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);

new \Kirki\Field\Text(
	[
		'settings' => 'button_404',
		'label'    => esc_html__( '404 Page Button Text', 'wonder-wall' ),
		'section'     =>'page_404',
		'priority' => 10,
		'active_callback' => [
			[
				'setting'  => 'button_switch_404',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);

new \Kirki\Section(
	'page_archive',
	[
		'title'       => esc_html__( 'Archive Page', 'wonder-wall' ),
		'panel'       => 'wonder_wall_page_settings',
		'priority'    => 160,
	]
);


new \Kirki\Section(
	'page_archive',
	[
		'title'       => esc_html__( 'Archive Page', 'wonder-wall' ),
		'panel'       => 'wonder_wall_page_settings',
		'priority'    => 160,
	]
);


new \Kirki\Field\Select(
	[
		'settings' => 'column_archive',
		'label'       => esc_html__( 'Number of Column', 'wonder-wall' ),
		'section'     => 'page_archive',
		'default'     => '4',
		'placeholder' => esc_html__( 'Choose an option', 'wonder-wall' ),
		'choices'     => [
			'12' => esc_html__( '1', 'wonder-wall' ),
			'6' => esc_html__( '2', 'wonder-wall' ),
			'4' => esc_html__( '3', 'wonder-wall' ),
			'3' => esc_html__( '4', 'wonder-wall' ),
			'2' => esc_html__( '6', 'wonder-wall' ),
			'1' => esc_html__( '12', 'wonder-wall' ),

		],
	]
);

new \Kirki\Field\Select(
	[
		'settings' => 'column_space_archive',
		'label'       => esc_html__( 'Column Space', 'wonder-wall' ),
		'section'     => 'page_archive',
		'default'     => '5',
		'placeholder' => esc_html__( 'Choose an option', 'wonder-wall' ),
		'choices'     => [
			'1' => esc_html__( '4', 'wonder-wall' ),
			'2' => esc_html__( '8', 'wonder-wall' ),
			'3' => esc_html__( '16', 'wonder-wall' ),
			'4' => esc_html__( '24', 'wonder-wall' ),
			'5' => esc_html__( '48', 'wonder-wall' ),
		],
	]
);

new \Kirki\Field\Text(
	[
		'settings' => 'button_archive',
		'label'    => esc_html__( 'Button Text', 'wonder-wall' ),
		'section'     => 'page_archive',
		'priority' => 10,
	]
);



/*====== Header Color Section ======*/
new \Kirki\Section(
	'wonder_wall_page_settings_section',
	[
		'title'       => esc_html__( 'Header', 'wonder-wall' ),
		'priority'    => 10,
		'panel'       => 'wonder_wall_page_settings',
	]
);




/*====== Social Media Settings Section ======*/
new \Kirki\Section(
	'wonder_wall_social-media_settings',
	[
		'title'       => esc_html__( 'Social Media Setttings', 'wonder-wall' ),
		'icon' 		  => 'dashicons-share',
		'priority'    => 2,
	]
);

/*====== Social Media Fields ======*/
new \Kirki\Field\Repeater(
	[
		'settings' => 'social_repeater_setting',
		'label'    => esc_html__( 'Repeater Control', 'wonder-wall' ),
		'section'  => 'wonder_wall_social-media_settings',
		'priority' => 10,
		'default'  => [
			[
				'link_text'   => esc_html__( 'Facebook', 'wonder-wall' ),
				'link_url'    => 'https://www.facebook.com/',
				'link_target' => '_self',
				'checkbox'    => false,
			],
			[
				'link_text'   => esc_html__( 'Twitter', 'wonder-wall' ),
				'link_url'    => 'https://www.twitter.com/',
				'link_target' => '_blank',
				'checkbox'    => true,
			],
		],
		'button_label' => esc_html__( "Add New" ),
		'fields'   => [
			'link_text'   => [
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'wonder-wall' ),
				'default'     => '',
			],
			'link_url'    => [
				'type'        => 'text',
				'label'       => esc_html__( 'Link URL', 'wonder-wall' ),
				'default'     => '',
			],
			'select' => [
				'type' => 'select',
				'settings'    => 'select_setting',
				'label'       => esc_html__( 'Select Control', 'wonder-wall' ),
				'section'     => 'wonder_wall_social-media_settings',
				'default'     => 'facebook',
				'placeholder' => esc_html__( 'Social Media Icon', 'wonder-wall' ),
				'choices'     => [
					'facebook' => esc_html__( 'Facebook', 'wonder-wall' ),
					'twitter' => esc_html__( 'Twitter', 'wonder-wall' ),
					'pinterest' => esc_html__( 'Pinterest', 'wonder-wall' ),
					'instagram' => esc_html__( 'Instagram', 'wonder-wall' ),
					'tiktok' => esc_html__( 'Tiktok', 'wonder-wall' ),
					'flickr' => esc_html__( 'Flickr', 'wonder-wall' ),
					'linkedin' => esc_html__( 'Linkedin', 'wonder-wall' ),
					'youtube' => esc_html__( 'Youtube', 'wonder-wall' ),
					'vimeo' => esc_html__( 'Vimeo', 'wonder-wall' ),
					'github' => esc_html__( 'Github', 'wonder-wall' ),
					'codepen' => esc_html__( 'Codepen', 'wonder-wall' ),
					'soundcloud' => esc_html__( 'Soundcloud', 'wonder-wall' ),
					'yelp' => esc_html__( 'Yelp', 'wonder-wall' ),
					'deviantart' => esc_html__( 'deviantart', 'wonder-wall' ),
				],
			],
			'link_target' => [
				'type'        => 'select',
				'label'       => esc_html__( 'Link Target', 'wonder-wall' ),
				'default'     => '_self',
				'choices'     => [
					'_blank' => esc_html__( 'New Window', 'wonder-wall' ),
					'_self'  => esc_html__( 'Same Frame', 'wonder-wall' ),
				],
			],
		],
	]
);

/*====== General Settings Section ======*/
new \Kirki\Section(
	'wonder_wall_general_settings_section',
	[
		'title'       => esc_html__( 'General Setttings', 'wonder-wall' ),
		'icon' 		  => 'dashicons-admin-site-alt3',
		'priority'    => 3,
	]
);

/*====== Animation On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'animation-switcher',
        'label'       => esc_html__( 'Animation On/Off', 'wonder-wall' ),
        'section'     => 'wonder_wall_general_settings_section',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'On', 'wonder-wall' ),
            'off' => esc_html__( 'Off', 'wonder-wall' ),
        ],
	]
);


/*====== Back to Top On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'back-top-switcher',
        'label'       => esc_html__( 'Back to Top On/Off', 'wonder-wall' ),
        'section'     => 'wonder_wall_general_settings_section',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'On', 'wonder-wall' ),
            'off' => esc_html__( 'Off', 'wonder-wall' ),
        ],
	]
);




/*====== Footer Settings Section ======*/
new \Kirki\Section(
	'wonder_wall_footer_settings_section',
	[
		'title'       => esc_html__( 'Footer Setttings', 'wonder-wall' ),
		'icon' 		  => 'dashicons-align-wide',
		'priority'    => 3,
	]
);

/*====== Footer On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'footer on/off',
		'label'       => esc_html__( 'Footer ', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);

/*====== Newsletter On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'newsletter on/off',
		'label'       => esc_html__( 'Newsletter On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Newsletter On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
		'active_callback' => [
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);

/*====== Mailchimp ID======*/
new \Kirki\Field\Text(
	[
		'settings'    => 'wonder_wall_footer_newsletter_form_id',
		'label'       => esc_html__( 'Newsletter Form ID', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'active_callback'  => [
			[
				'setting'  => 'newsletter on/off',
				'operator' => '===',
				'value'    => true,
			],
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			],
	    ]
	]
);

/*====== Newsletter Title On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'newsletter_title on/off',
		'label'       => esc_html__( 'Newsletter Title ', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
		'active_callback' => [
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);


/*====== Newsletter Title======*/
new \Kirki\Field\Text(
	[
		'settings'    => 'wonder_wall_footer_newsletter_title',
		'label'       => esc_html__( 'Newsletter Title', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'active_callback'  => [
			[
				'setting'  => 'newsletter_title on/off',
				'operator' => '===',
				'value'    => true,
			],
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			],
	    ]
	]
);

/*====== Newsletter Subtitle On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'newsletter_subtitle on/off',
		'label'       => esc_html__( 'Newsletter Subtitle ', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
		'active_callback' => [
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);



/*====== Newsletter Subtitle======*/
new \Kirki\Field\Text(
	[
		'settings'    => 'wonder_wall_footer_newsletter_subtitle',
		'label'       => esc_html__( 'Newsletter Subtitle', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'active_callback'  => [
			[
				'setting'  => 'newsletter_subtitle on/off',
				'operator' => '===',
				'value'    => true,
			],
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			],
	    ]
	]
);


new \Kirki\Field\Editor(
	[
		'settings'    => 'footer-copyright-text',
		'label'       => esc_html__( 'Copyright Text', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'active_callback' => [
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);

/*====== Footer Brand Logo Section On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'footer-brand-logo on/off',
		'label'       => esc_html__( 'Footer Brand Logo On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Footer Brand Logo On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);

/*====== Footer Brand Logo Section ======*/
new \Kirki\Field\Repeater(
	[
		'settings' => 'repeater_footer_setting',
		'label'    => esc_html__( 'Footer Brand Logos', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'fields' => array(
			'brand_logo_link' => array(
				'type'        => 'text',
				'label'       => esc_attr__( 'Image Link', 'wonder-wall' ),
				'default'     => '',
			),
			'brand_logo_image' => array(
				'type'        => 'image',
				'label'       => esc_attr__( 'Image', 'wonder-wall' ),
				'default'     =>  '',

			),
		),

		'active_callback' => [
			[
				'setting'  => 'footer-brand-logo on/off',
				'operator' => '==',
				'value'    => true,
			]
		],

	]
);

/*====== Footer Bottom Area On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'footer-bottom-area on/off',
		'label'       => esc_html__( 'Footer Bottom Area On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Footer Brand Bottom Area On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);


new \Kirki\Field\Editor(
	[
		'settings'    => 'footer-bottom-area-copyright-text',
		'label'       => esc_html__( 'Footer Bottom Copyright Text', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'active_callback' => [
			[
				'setting'  => 'footer on/off',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'footer-bottom-area on/off',
				'operator' => '==',
				'value'    => true,
			],
		],
	]
);

/*====== Footer Bottom Area On/Off ======*/
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'footer-social-media on/off',
		'label'       => esc_html__( 'Footer Social Media On/Off', 'wonder-wall' ),
		'description' => esc_html__( 'Footer Social Media On/Off Control', 'wonder-wall' ),
		'section'     => 'wonder_wall_footer_settings_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'On', 'wonder-wall' ),
			'off' => esc_html__( 'Off', 'wonder-wall' ),
		],
	]
);





/*====== Color Section ======*/
new \Kirki\Panel(
	'colors_settings',
	[
		'priority'    => 3,
		'title'       => esc_html__( 'Color Setttings', 'wonder-wall' ),
		'icon' => 'dashicons-admin-customizer',
	]
);

/*====== Header Color Section ======*/
new \Kirki\Section(
	'wonder_wall_color_settings_section',
	[
		'title'       => esc_html__( 'Header', 'wonder-wall' ),
		'priority'    => 10,
		'panel'       => 'colors_settings',
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'header_topbar_bg_color',
		'label'       => __( 'Header Topbar Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Topbar Background Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#EBC6BE',
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_bg_color',
		'label'       => __( 'Header Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Background Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => 'transparent',
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'header_mobile_menu_bg_color',
		'label'       => __( 'Header Mobile Menu Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Mobile Background Color ', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#fff',
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_mobile_menu_text_color',
		'label'       => __( 'Header Side Menu Text Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Mobile Menu Text Color ', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#000',
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_mobile_menu_text_hover_color',
		'label'       => __( 'Header Side Menu Text Hover Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Mobile Menu Text Hover Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#C88E84',
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_menu-text-color',
		'label'       => __( 'Header Menu Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select Header Menu color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#2D2E2E',
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_menu_hover_color',
		'label'       => __( 'Header Menu Hover Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select Header Menu Hover Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#C78D84',
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'header_sub_menu_background',
		'label'       => __( 'Header Sub Menu Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Sub Menu Background Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#fff'
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_icon_hover_color',
		'label'       => __( 'Header Icon Hover Color', 'wonder-wall' ),
		'description' => esc_html__( 'Header Social Media Hover Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_settings_section',
		'default' => '#000'
	]
);



/*====== Sidebar Section ======*/

new \Kirki\Panel(
	'sidebar_color',
	[
		'title'       => esc_html__( 'Sidebar', 'wonder-wall' ),
		'panel'       => 'colors_settings',
		'priority'    => 160,
	]
);


new \Kirki\Section(
	'newsletter_color',
	[
		'title'       => esc_html__( 'Newsletter', 'wonder-wall' ),
		'panel'       => 'sidebar_color',
		'priority'    => 160,
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar-newsletter-widget-title_setting',
		'label'       => __( 'Sidebar Newsletter Title', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter widget title', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#111'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar-newsletter-widget-desc_setting',
		'label'       => __( 'Sidebar Newsletter Descrption', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter widget description', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#111'
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_newsletter_button_bg_color_setting',
		'label'       => __( 'Newsletter Button Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter button background color', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#C88E84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_newsletter_button_text_color_setting',
		'label'       => __( 'Newsletter Button Text Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter button text color', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#fff'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_newsletter_button_border_color_setting',
		'label'       => __( 'Newsletter Button Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter button color', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#C88E84'
	]
);



new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_newsletter_button_hover_bg_color_setting',
		'label'       => __( 'Newsletter Button Hover Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter button background color', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#ffffff00'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_newsletter_button_hover_text_color_setting',
		'label'       => __( 'Newsletter Button Hover Text Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter button text color', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#C88E84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_newsletter_button_hover_border_color_setting',
		'label'       => __( 'Newsletter Button Hover Border Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select newsletter button border color', 'wonder-wall' ),
		'section'     => 'newsletter_color',
		'default' => '#C88E84'

	]
);

new \Kirki\Section(
	'sidebar-social_color',
	[
		'title'       => esc_html__( 'Social Media', 'wonder-wall' ),
		'panel'       => 'sidebar_color',
		'priority'    => 160,
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_social_color_setting',
		'label'       => __( 'Social Media Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select social media color', 'wonder-wall' ),
		'section'     => 'sidebar-social_color',
		'default' => '#C88E84'

	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_social_hover_color_setting',
		'label'       => __( 'Social Media Hover Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select social media hover color', 'wonder-wall' ),
		'section'     => 'sidebar-social_color',
		'default' => '#7D4D3D'

	]
);

new \Kirki\Section(
	'sidebar-blog_color',
	[
		'title'       => esc_html__( 'Blog', 'wonder-wall' ),
		'panel'       => 'sidebar_color',
		'priority'    => 160,
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_blog_color_setting',
		'label'       => __( 'Blog Date Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select blog date color', 'wonder-wall' ),
		'section'     => 'sidebar-blog_color',
		'default' => '#C88E84'

	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_blog_title_color_setting',
		'label'       => __( 'Blog Title Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select blog title color', 'wonder-wall' ),
		'section'     => 'sidebar-blog_color',
		'default' => '#111'

	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'sidebar_blog_title_hover_color_setting',
		'label'       => __( 'Blog Title Hover Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select blog title hover color', 'wonder-wall' ),
		'section'     => 'sidebar-blog_color',
		'default' => '#C88E84'
	]
);




/*===== CONTACT BOX ======*/

new \Kirki\Section(
	'contact_box_section',
	[
		'title'       => esc_html__( 'Contact Box', 'wonder-wall' ),
		'panel'       => 'sidebar_color',
		'priority'    => 160,
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'contact_box_icon_color_setting',
		'label'       => __( 'Contact Box Icon Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select contact box icon color', 'wonder-wall' ),
		'section'     => 'contact_box_section',
		'default' => '#C88E84'

	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'contact_box_text_color_setting',
		'label'       => __( 'Contact Box Text Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select contact box text color', 'wonder-wall' ),
		'section'     => 'contact_box_section',
		'default' => '#2D2E2E'

	]
);



/*====== Footer Color Section ======*/
new \Kirki\Section(
	'wonder_wall_color_footer_settings_section',
	[
		'title'       => esc_html__( 'Footer', 'wonder-wall' ),
		'priority'    => 10,
		'panel'       => 'colors_settings',
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'footer_bg-color_setting',
		'label'       => __( 'Footer Background Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select footer background color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#F4EFEC'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_newsletter-title-color',
		'label'       => __( 'Footer Newsletter Title Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#C88E84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_newsletter-subtitle-color',
		'label'       => __( 'Footer Newsletter Subtitle Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#2D2E2E'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_newsletter-button-bg-color',
		'label'       => __( 'Footer Newsletter Button Background Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#C88E84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_newsletter-button-text-color',
		'label'       => __( 'Footer Newsletter Button Text Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#fff'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_newsletter-button-bg-hover-color',
		'label'       => __( 'Footer Newsletter Button Background Hover Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#fff'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_logo-text-color',
		'label'       => __( 'Footer Logo Text Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#C78D84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_logo-copyright-text-color',
		'label'       => __( 'Footer Copyright Text Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#2D2E2E'
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'footer_widget-title',
		'label'       => __( 'Widget Title Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select Widget Title color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#2D2E2E'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_widget-content',
		'label'       => __( 'Widget Content Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select Widget Content color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#2D2E2E'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_copyright_color',
		'label'       => __( 'Footer Copyright Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select footer copyright color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#F4EFEC'
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'footer_bottom_copyright_bg_color',
		'label'       => __( 'Footer Bottom Copyright Background', 'wonder-wall' ),
		'description' => esc_html__( 'Select footer copyright background color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#C88E84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_social_media_color',
		'label'       => __( 'Footer Social Media Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#C88E84'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_social_media_bg_color',
		'label'       => __( 'Footer Social Media Background Color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#F4EFEC'
	]
);

new \Kirki\Field\Color(
	[
		'settings'    => 'footer_bottom_copyright_color',
		'label'       => __( 'Footer Copyright Color', 'wonder-wall' ),
		'description' => esc_html__( 'Select footer copyright color', 'wonder-wall' ),
		'section'     => 'wonder_wall_color_footer_settings_section',
		'default' => '#F4EFEC'
	]
);