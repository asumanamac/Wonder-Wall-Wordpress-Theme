const getPostFormat = () => wp.data.select('core/editor').getEditedPostAttribute('format');

// set the initial postFormat
let postFormat = getPostFormat();


wp.data.subscribe(() => {
    // get the current postFormat
    const newPostFormat = getPostFormat();

    // only do something if postFormat has changed.
    if (postFormat !== newPostFormat) {

        // Hide metabox fields based on conditions
        if (newPostFormat == 'gallery') {
            show_gallery_post();
            hide_video_post();
            hide_audio_post();
        }
        if (newPostFormat == 'video') {
            hide_gallery_post();
            show_video_post();
            hide_audio_post();
        }
        if (newPostFormat == 'audio') {
            hide_gallery_post();
            hide_video_post();
            show_audio_post();
        }
        if (newPostFormat == 'standard') {
            hide_gallery_post();
            hide_video_post();
            hide_audio_post();
        }

    }
    // update the postFormat variable.
    postFormat = newPostFormat;

});

/***
 * hide metabox settings function
 */


function hide_gallery_post() {
    document.getElementById("gallery-post-settings").style.display = "none";
}

function hide_video_post() {
    document.getElementById("post-video-settings").style.display = "none";
}

function hide_audio_post() {
    document.getElementById("audio-post-settings").style.display = "none";
}



/**
 * show metabox settings functions
 */
function show_gallery_post() {
    document.getElementById("gallery-post-settings").style.display = "block";
}

function show_video_post() {
    document.getElementById("post-video-settings").style.display = "block";
}

function show_audio_post() {
    document.getElementById("audio-post-settings").style.display = "block";
}