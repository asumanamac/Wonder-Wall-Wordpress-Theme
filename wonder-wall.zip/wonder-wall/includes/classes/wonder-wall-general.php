<?php

if (!function_exists('wonder_wall_theme_setup')) {
    function wonder_wall_theme_setup() {
        wp_enqueue_style( 'wonder-wall-fontawesome-all', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/css/all.min.css' );
        wp_enqueue_style( 'wonder-wall-bootstrap', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/css/bootstrap.min.css' );
        wp_enqueue_style( 'wonder-wall-lightbox', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/css/lightbox.css' );
        wp_enqueue_style( 'wonder-wall-swiper', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/css/swiper.min.css' );
        wp_enqueue_style( 'wonder_wall-custom-style', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/css/css-settings.css' );
        wp_enqueue_style( 'wonder-wall-animate', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/css/animate.min.css' );

        wp_enqueue_style( 'wonder-wall-style', get_stylesheet_uri() );


        wp_enqueue_script('wonder-wall-bootstrap', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/bootstrap.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-counter', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/counter.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-tweenmax', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/Timelinemax.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-isotope', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/isotope.pkgd.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-lightbox', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/lightbox.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-jquery', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/jquery-3.4.1.min.js', array( 'jquery' ), null, true );

        wp_enqueue_script('wonder-wall-sidebar', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/sticky-sidebar.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-swiper', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/swiper.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-gsap', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/gsap.min.js', array( 'jquery' ), null, true );
        wp_enqueue_script('wonder-wall-scrolltrigger', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/ScrollTrigger.min.js', array( 'jquery' ), null, true );

        wp_enqueue_script('wonder-wall-custom', WONDER_WALL_THEME_ADMIN_URL. '/includes/assets/js/eb-script.js', array( 'jquery' ), null, true );


    }
}
add_action('wp_enqueue_scripts', 'wonder_Wall_theme_setup');


/**
* WThe area where Wordpress features are installed
*
* @return    void
* @param    empty
*/

if (!function_exists('wonder_wall_theme_custom_setup')) {
    function wonder_wall_theme_custom_setup(){
        add_theme_support('automatic-feed-links',  array( 'post', 'page' ));
        add_theme_support('post-thumbnails');
        add_image_size( 'wonder-wall-blog1', 408,522 ,true );
        add_image_size( 'wonder-wall-blog2', 345,517 ,true );
        add_image_size( 'wonder-wall-blog3', 330,420 ,true );
        add_image_size( 'wonder-wall-image1', 390,575 ,true );
        add_image_size( 'wonder-wall-blog4', 336,510 ,true );
        add_image_size( 'wonder-wall-category1', 267,98 ,true );
        add_image_size( 'wonder-wall-category2', 240,310 ,true );
        add_image_size( 'wonder-wall-hero2', 415,605 ,true );
        add_image_size( 'wonder-wall-hero3', 455,605 ,true ); 

        add_theme_support( 'custom-background', array( 'default-color' => 'ffffff') );
        add_theme_support('post-formats', array('video'));
        add_theme_support( 'custom-background', array( 'default-color' => 'ffffff') );
    }
}
add_action('after_setup_theme', 'wonder_wall_theme_custom_setup');



function add_custom_class_to_post_thumbnail($html, $post_id, $post_thumbnail_id, $size, $attr) {
    // Eklemek istediğiniz sınıf
    $custom_class = 'blog-main-image'; 
    
    // <img> etiketine sınıf ekleme
    $html = str_replace('class="', 'class="' . $custom_class . ' ', $html);
    
    return $html;
}
add_filter('post_thumbnail_html', 'add_custom_class_to_post_thumbnail', 10, 5);



/***
 *
 * Display Title for all pages
 *
 */

function wonder_wall_title($type , $title , $link){
    if($link == false){
    ?>
       <div class="post-title"><<?php echo $type ?>><?php echo $title ?></<?php echo $type ?>></div>
    <?php
    }
    if($link == true){
        ?>
         <div class="post-title"><a href="<?php echo get_the_permalink() ?>"><<?php echo $type ?>><?php echo $title ?></<?php echo $type ?>></a></div>

        <?php

    }
}

/***
 *
 * Display Tags for all pages
 *
 */

function wonder_wall_display_tags(){
$posttags = get_the_tags();
if ($posttags) {
  foreach($posttags as $tag) {
    echo '<li><a href="'.   get_tag_link($tag->term_id) .'">' . $tag->name . '</a></li> ';  
  }
}

}

/***
 *
 * Display Categories for all pages
 *
 */

function wonder_wall_display_categories(){
    $categories = get_the_category( get_the_ID() );
foreach($categories as $category) {
   echo '<li><a href="' . get_category_link($category->term_id) . '">' . esc_attr($category->name) . '</a></li>';
}
}

/***
 *
 * Metabox Admin Settings
 *
 */


/***
 *
 * Post Comment Count Div for Single Pages
 *
 */

 add_action('woocommerce_before_main_content', 'custom_breadcrumb_visibility', 5);
function custom_breadcrumb_visibility() {
    // MetaBox ile eklenen 'show_breadcrumb' değerini al
    $show_breadcrumb = get_post_meta(get_the_ID(), 'show_breadcrumb', true);

    // Eğer show_breadcrumb değeri 0 ise, breadcrumb'ı gizle
    if ($show_breadcrumb != 1) {
        remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
    }
}


 

function wonder_wall_post_comment_count(){ 
	$num_comments = get_comments_number();
	if ( $num_comments == 0 ) {
		$comments = esc_html__( '0', 'wonder-wall' );
	}
	elseif ( $num_comments > 1 ) {
		$comments = $num_comments; 
	}
	else {
		$comments = esc_html__( '1', 'wonder-wall' );
	}
	$output = '';
  $output = '<div class="post-comment"><a class="postcommentcount" href="' . get_permalink() . '"><span>'. $comments .'</span><i class="fa fa-comments"></i></a></div>';

	return $output;
}


/***
 *
 * Post Shares Div for Single Pages
 *
 */

function wonder_wall_post_share($post_ID){
    $social_arrays  = get_theme_mod( 'repeater_setting');
    ?>
    <ul>
    <?php foreach ($social_arrays as $key => $value) : ?>					
		<li><a class="<?php echo esc_attr($value['link_text']) ?>" href="<?php echo esc_url($value['link_url']); ?>" target="<?php echo esc_attr($value['link_target']); ?>">
			<i class="fa fa-<?php echo esc_attr($value['select']); ?>"></i></a></li>
		<?php endforeach; ?>
    </ul>
<?php
}



/***
 *
 * Post Direction div for single pages
 *
 */
function wonder_wall_post_direction(){
    ?>
        <div class="prev-post col-md-6 col-sm-12 col-xs-12">
            <?php previous_post_link('%link' , '<span>Previous Article</span><h2>%title</h2>' , false); ?>
        </div><!-- prev-post -->
        <div class="next-post col-md-6 col-sm-12 col-xs-12">
            <?php next_post_link('%link' , '<span>Next Article</span><h2>%title</h2>' , false); ?>
        </div><!-- next-post -->
    <?php
}

function wonder_wall_blog_post_direction(){
    ?>
        <div class="blog-pagination-buttons">
            <?php previous_post_link('<a href="%link" class="previous-post"><i class="fa fa-angle-double-left"></i>PREVIOUS POSTS</a>' , false); ?>

        <?php next_post_link( '<a href="%link" class="older-post"><i class="fa fa-angle-double-left"></i>OLDER POSTS</a>' , false); ?>
        </div><!-- next-post -->
    <?php
}

/***
 *
 * Comment Field Rearrange
 *
 */

// function wonder_wall_comment_fields_order( $fields ) {
//     $comment_field = $fields['comment'];
//     $cookies_field = $fields['cookies'];
//     unset( $fields['comment'] );
//     unset( $fields['cookies'] );
//     $fields['comment'] = $comment_field;
//     $fields['cookies'] = $cookies_field;
//     return $fields;
// }
// add_filter( 'comment_form_fields', 'wonder-wall_comment_fields_order');

/***
 *
 * Load Single Pages JS
 *
 */

// function wonder_wall_load_admin_scripts() {
//     wp_enqueue_script('wonder-wall-admin-js', WONDER_WALL_THEME_URL. '/includes/admin/assets/admin.js', array( 'jquery' ), null, true );
// }
// add_action( 'admin_enqueue_scripts', 'wonder-wall_load_admin_scripts' );

/***
 * 
 * Register General Sidebar
 * 
 */


function wonder_wall_general_sidebar()
{
    register_sidebar( array(
        'name'          => __('General Sidebar','wonder-wall'),
        'id'            => 'sidebar-general',
        'before_widget' => '<div class="eb-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="widget-title">',
        'after_title'   => '</div>',
    ) );
}

add_action('widgets_init','wonder_wall_general_sidebar');

/***
 * 
 * Register Footer Sidebar 1
 * 
 */

function wonder_wall_footer_sidebar_one()
{
    register_sidebar( array(
        'name'          => __('Footer Column 1','wonder-wall'),
        'id'            => 'sidebar-footer1',
        // 'before_widget' => '<div class="col-md-4 eb-footer-widget-logo">',
        // 'after_widget'  => '</div>',
        'before_title'  => '<div class="eb-widget-title">',
        'after_title'   => '</div>',
    ) );
}

add_action('widgets_init','wonder_wall_footer_sidebar_one');

/***
 * 
 * Register Footer Sidebar 2
 * 
 */

function wonder_wall_footer_sidebar_two()
{
    register_sidebar( array(
        'name'          => __('Footer Column 2','wonder-wall'),
        'id'            => 'sidebar-footer2',
        // 'before_widget' => '<div class="col-md-4 widget eb-footer-working-hours-widget">',
        // 'after_widget'  => '</div>',
        'before_title'  => '<div class="eb-widget-title">',
        'after_title'   => '</div>',
    ) );
}

add_action('widgets_init','wonder_wall_footer_sidebar_two');

/***
 * 
 * Register Footer Sidebar 3
 * 
 */

function wonder_wall_footer_sidebar_three()
{
    register_sidebar( array(
        'name'          => __('Footer Column 3','wonder-wall'),
        'id'            => 'sidebar-footer3',
       
        'before_title'  => '<div class="eb-widget-title">',
        'after_title'   => '</div>',
    ) );
}

add_action('widgets_init','wonder_wall_footer_sidebar_three');


/**
 * 
 * Register Single Sidebar
 * 
 */

function wonder_wall_single_sidebar()
{
    register_sidebar( array(
        'name'          => __('Single Sidebar','wonder-wall'),
        'id'            => 'sidebar-single',
        'before_widget' => '<div class="eb-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="widget-title">',
        'after_title'   => '</div>',
    ) );
}

add_action('widgets_init','wonder_wall_single_sidebar');


/**
 * 
 * Register Archive Sidebar
 * 
 */

function wonder_wall_archive_sidebar()
{
    register_sidebar( array(
        'name'          => __('Archive Sidebar','wonder-wall'),
        'id'            => 'sidebar-archive',
        'before_widget' => '<aside class="widget">',
        'after_widget'  => '</aside>',
        'before_title'  => '<div class="widget-title">',
        'after_title'   => '</div>',
    ) );
}

add_action('widgets_init','wonder_wall_archive_sidebar');



/***
 * 
 * 
 * Author Info
 * 
 */

if ( ! function_exists( 'wonder_wall_custom_profile_methods' ) ) {
    function wonder_wall_custom_profile_methods( $wonder_wall_profile_fields ) {
        $wonder_wall_profile_fields['facebook'] = esc_html__( 'Facebook URL', 'wonder-wall' );
        $wonder_wall_profile_fields['twitter'] = esc_html__( 'Twitter URL', 'wonder-wall' );
        $wonder_wall_profile_fields['instagram'] = esc_html__( 'Instagram URL', 'wonder-wall' );
        $wonder_wall_profile_fields['googleplus'] = esc_html__( 'Google+ URL', 'wonder-wall' );
        $wonder_wall_profile_fields['pinterest'] = esc_html__( 'Pinterest URL', 'wonder-wall' );
        $wonder_wall_profile_fields['mail'] = esc_html__( 'Mail', 'wonder-wall' );
        return $wonder_wall_profile_fields;
    }
}
add_filter( 'user_contactmethods', 'wonder_wall_custom_profile_methods' );


/***
 *
 * Single Author Bio
 *
 */

function wonder_wall_post_single_author_bio(){
    if (!empty(get_the_author_meta('description'))) {
		$author_desc = get_the_author_meta('description', get_the_author_meta('ID'));
        ?>
        <div class="col-md-12 col-sm-12 col-xs-12 post-author">
            <div class="post-author-content">
                <div class="post-author-inwrap">
				    <div class="author-image">
					    <?php echo get_avatar( get_the_author_meta( 'email' ), 120 ); ?>
                    </div><!-- author-image -->
				    <div class="author-info">
					    <div class="author-name">
						    <?php printf( '<h3><a href="%1$s">%2$s</a>', esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ), esc_attr( get_the_author() , '</h3>' ) ); ?>
                        </div><!--author-name-->
					    <div class="author-text">
						    <p><?php echo get_the_author_meta('description', get_the_author_meta('ID')); ?></p>
					    </div><!-- author-text -->
					    <div class="author-social-media">
						    <ul>
							    <?php if(get_the_author_meta('facebook')) : ?>
								    <li>
									    <a target="_blank" class="facebook" href="<?php echo the_author_meta('facebook'); ?>"><i class="fa fa-facebook"></i></a>
								    </li>
							    <?php endif; ?>
							    <?php if(get_the_author_meta('twitter')) : ?>
								    <li>
									    <a target="_blank" class="twitter" href="<?php echo the_author_meta('twitter'); ?>"><i class="fa fa-twitter"></i></a>
								    </li>
							    <?php endif; ?>

							    <?php if(get_the_author_meta('instagram')) : ?>
								    <li>
									    <a target="_blank" class="instagram" href="<?php echo the_author_meta('instagram'); ?>" ><i class="fa fa-instagram"></i></a>
								    </li>
							    <?php endif; ?>
							    <?php if(get_the_author_meta('googleplus')) : ?>
								    <li>
									    <a target="_blank" class="google" href="<?php echo the_author_meta('googleplus'); ?>?rel=author"><i class="fa fa-google-plus"></i></a>
								    </li>
							    <?php endif; ?>

							    <?php if(get_the_author_meta('pinterest')) : ?>
								    <li>
									    <a target="_blank" class="pinterest" href="<?php echo the_author_meta('pinterest'); ?>" ><i class="fa fa-pinterest"></i></a>
								    </li>
							    <?php endif; ?>
							    <?php if(get_the_author_meta('mail')) : ?>
								    <li>
									    <a target="_blank" class="mail" href="mailto:<?php echo the_author_meta('mail'); ?>"><i class="fa fa-mail"></i></a>
								    </li>
							    <?php endif; ?>
						    </ul>
					    </div><!-- author-social-media -->
				    </div><!-- author-info -->
			    </div><!--post-author-inwrap -->
		    </div><!--post-author-content -->
        </div><!--post-author -->
        <?php
    }
}

/**
 * 
 * Single Related Post
 * 
 */


function wonder_wall_single_related($post_id){
	if (get_theme_mod('related_on_off' , 'on') == true) {
		global $post;
		$postcat = wp_get_post_categories( $post->ID );
		$postcat_sub = get_term_children( $postcat[0] , 'category');
		$postcat_sub_echo = array_merge($postcat, $postcat_sub); 
		$args = array(
			'post__not_in' => array( $post->ID ),
			'posts_per_page' => 4,
			'orderby' => 'rand',
			'category__in' => $postcat_sub_echo,
			'posts_per_page' 	=> 4,
		);
		$cats_array = array();
		$cat_ids = wp_get_post_categories( $post->ID, array( 'fields' => 'ids' ) );
		foreach ( $cat_ids as $cat ) {
			$cats_array[] = $cat;
		}
		$cats_array  = array_map( 'absint', $cats_array );
		//$args[ 'category__in' ] = $cats_array;
		$related_query = new WP_Query( $args );
		?>
		<div class=" related-post">
            <div class="related-post-content">
                <?php while ( $related_query->have_posts() ) : $related_query->the_post(); ?>
                    <article class="post">
                        <?php if(has_post_thumbnail()) { ?>
                            <div class="post-type-image">
                                <a href="<?php echo get_permalink(get_the_ID()); ?>"><img src="<?php  echo wp_get_attachment_image_src(get_post_thumbnail_id() , 'wonder-wall-related-post-image')[0] ?>" alt=""></a>
                            </div><!--post-type-image-->
                            <div class="post-title">
                                <h3><a href="<?php echo get_permalink(get_the_ID()); ?>"><?php echo get_the_title(); ?></a></h3>
                            </div><!--post-title-->
                            <div class="post-date">
                                <a href="<?php echo get_day_link(get_post_time('Y'), get_post_time('m'), get_post_time('j'));  ?>"><?php echo get_the_date(); ?></a>
						    </div><!--post-date-->
                        <?php } ?>
                    </article><!--post-->
				<?php endwhile; 
                wp_reset_postdata(); ?>
            </div><!-- related-post-content -->
        </div><!-- related-post -->
		<?php
	}
}


/**
 *
 * Css Echo
 *
 */
function wonder_wall_css_echo($customizer_typography_id,$selector, $where, $default='',$important=''){
    $css = '';
    if ($where == 'background-color') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{background-color:'.$default . $important .';}';
        }
        else{
            $css .= $selector;
            $css .= '{background-color:'.get_theme_mod($customizer_typography_id) . $important .';}';    
        }
    }
    if ($where == 'top') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{top:'.$default .';}';
        }
        else{
            $css .= $selector;
            $css .= '{top:'.get_theme_mod($customizer_typography_id).';}';
        }
    }
    elseif ($where == 'border-color') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{border-color:'.$default . $important .';}';
        }
        else{
            $css .= $selector;
            $css .= '{border-color:'.get_theme_mod($customizer_typography_id) . $important .';}';
        }
    }
    elseif ($where == 'color') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{color:'.$default . $important .';}';
        }
        else{
            $css .= $selector;
            $css .= '{color:'.get_theme_mod($customizer_typography_id). $important .';}';
        }
    }
    elseif ($where == 'fill') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{fill:'.$default . $important .';}';
        }
        else{
            $css .= $selector;
            $css .= '{fill:'.get_theme_mod($customizer_typography_id). $important .';}';
        }
    }
    elseif ($where == 'max-height') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{max-height:'.$default .';}';
        }
        else{
            $css .= $selector;
            $css .= '{max-height:'.get_theme_mod($customizer_typography_id).';}';
        }
    }
    elseif ($where == 'paddingTopBottom') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{padding:'.$default .' 0px;}';
        }
        else{
            $css .= $selector;
            $css .= '{padding:'.get_theme_mod($customizer_typography_id).' 0px;}';
        }
    }
    elseif ($where == 'paddingleft') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{padding-left:'.$default .'px;}';
        }
        else{
            $css .= $selector;
            $css .= '{padding-left:'.get_theme_mod($customizer_typography_id).'px;}';
        }
    }
    elseif ($where == 'paddingright') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{padding-right:'.$default .'px;}';
        }
        else{
            $css .= $selector;
            $css .= '{padding-right:'.get_theme_mod($customizer_typography_id).'px;}';
        }
    }
    elseif ($where == 'stroke') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{stroke:'.$default .';}';
        }
        else{
            $css .= $selector;
            $css .= '{stroke:'.get_theme_mod($customizer_typography_id).';}';
        }
    }
    elseif ($where == 'border-top-color') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{border-top-color:'.$default .';}';
        }
        else{
            $css .= $selector;
            $css .= '{border-top-color:'.get_theme_mod($customizer_typography_id).';}';
        }
    }
    elseif ($where == 'gradient') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{'. $default.';}' ;
        }
        else{
            $css .= $selector;
            $css .= '{'. get_theme_mod($customizer_typography_id).';}' ;
        }
    }
    elseif ($where == 'height') {
        if (get_theme_mod($customizer_typography_id)=='') {
            $css .= $selector;
            $css .= '{'. $default.';}' ;
        }
        else{
            $css .= $selector;
            $css .= '{height:'.get_theme_mod($customizer_typography_id).';}' ;
        }
    }
    return $css;
}



/**
 * 
 * Post Pagination
 * 
 */
function wonder_wall_post_pagination() {
    global $wp_query;
    $total = $wp_query->max_num_pages;
    if ( $total > 1 ) {
        if ( !$current_page = get_query_var('paged') ) {
            $current_page = 1;
        }
        $links= paginate_links(array(
            'base' => preg_replace('/\?.*/', '/', get_pagenum_link(1)) . '%_%',
            'format' => '?paged=%#%',
            'current' => $current_page,
            'total' => $total,
            'mid_size' => 4,
            'type' => 'list',
            'paged' => $current_page,
            'posts_per_page'    => 3,
            'prev_next'   => true,
            'prev_text'    => __( 'Prev', 'wonder-wall' ),
            'next_text'    => __( 'Next', 'wonder-wall'),
        ));

    $find = array("<ul class='page-numbers'>" , "<li>" , "<a class='page-numbers'>");
    $replace = array("<ul class='page-numbers '>" , "<li class='pagination-item'>" , "<a class='page-link'>");
    $links = str_replace($find , $replace , $links);

    echo $links;
    }
}

function wonder_wall_archive_title(){
    if ( is_tag() ) :
        echo '<div class="wonder-wall-title-wrapper">';
        echo '<div class="archive-title">'.esc_html__( 'Tag', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . single_tag_title( '', false ) . '</h1>' );
    elseif ( is_day() ) :
        echo '<div class="wonder-wall-title-wrapper">';
        echo '<div class="archive-title">'.esc_html__( 'Daily Archives', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . get_the_date() . '</h1>' );
    elseif ( is_month() ) :
        echo '<div class="wonder-wall-title-wrapper">';
        //printf( esc_html__('Monthly Archives: %s', 'wonder-wall' ), '<div>' . get_the_date( 'F Y' ) . '</div>' );
        echo '<div class="archive-title">'.esc_html__( 'Monthly Archives', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . get_the_date( 'F Y' ) . '</h1>' );
    elseif ( is_year() ) :
        echo '<div class="wonder-wall-title-wrapper">';
        //printf( esc_html__('Yearly Archives: %s', 'wonder-wall' ), '<div>' . get_the_date( 'Y' ) . '</div>' );
        echo '<div class="archive-title">'.esc_html__( 'Yearly Archives', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . get_the_date( 'Y' ) . '</h1>' );
    elseif ( is_tax( 'post_format', 'post-format-aside' ) ) :
        echo '<div class="wonder-wall-title-wrapper">';
        //esc_html_e( 'Asides', 'wonder-wall' );
        echo '<div class="archive-title">'.esc_html__( 'Post format', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . esc_html__( 'Aside', 'wonder-wall' ) . '</h1>' );
    elseif ( is_tax( 'post_format', 'post-format-image' ) ) :
        echo '<div class="wonder-wall-title-wrapper">';
        //esc_html_e( 'Images', 'wonder-wall');
        echo '<div class="archive-title">'.esc_html__( 'Post format', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . esc_html__( 'Images', 'wonder-wall' ) . '</h1>' );
    elseif ( is_tax( 'post_format', 'post-format-video' ) ) :
        echo '<div class="wonder-wall-title-wrapper">';
        //esc_html_e( 'Videos', 'wonder-wall' );
        echo '<div class="archive-title">'.esc_html__( 'Post format', 'wonder-wall' ).'</div>';
        echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
        echo '</div>';
        echo ( '<h1 class="wonder-wall-title">' . esc_html__( 'Videos', 'wonder-wall' ) . '</h1>' );
        elseif ( is_tax( 'post_format', 'post-format-quote' ) ) :
            echo '<div class="wonder-wall-title-wrapper">';
            //esc_html_e( 'Quotes', 'wonder-wall' );
            echo '<div class="archive-title">'.esc_html__( 'Post format', 'wonder-wall' ).'</div>';
            echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
            echo '</div>';
            echo ( '<h1 class="wonder-wall-title">' . esc_html__( 'Quotes', 'wonder-wall' ) . '</h1>' );
        elseif ( is_tax( 'post_format', 'post-format-link' ) ) :
            echo '<div class="wonder-wall-title-wrapper">';
            //esc_html_e( 'Links', 'wonder-wall' );
            echo '<div class="archive-title">'.esc_html__( 'Post format', 'wonder-wall' ).'</div>';
            echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
            echo '</div>';
            echo ( '<h1 class="wonder-wall-title">' . esc_html__( 'Links', 'wonder-wall' ) . '</h1>' );
        else :
            echo '<div class="wonder-wall-title-wrapper">';
            //esc_html_e( 'Archives', 'wonder-wall' );
            echo '<div class="archive-title">'.esc_html__( 'Posts', 'wonder-wall' ).'</div>';
            echo ( '<div class="wonder-wall-total-posts">' . esc_attr($wp_query->found_posts) . '</div>' );
            echo '</div>';
            echo ( '<h1 class="wonder-wall-title">' . esc_html__( 'Archives', 'wonder-wall' ) . '</h1>' );
        endif;
}

function wonder_wall_output_single_media($embed){
     if ($embed !='') {
        global $wp_embed;
            echo $wp_embed->run_shortcode('[embed]'.$embed.'[/embed]');
        }
}

add_filter('body_class', 'custom_body_class');
function custom_body_class($classes) {
    if (is_page(1189))
        $classes[] = 'home';
    return $classes;
}


/*======
*
* Get Sidebar
*
======*/
if( !function_exists( 'wonder_wall_get_sidebar' ) ) {

	function wonder_wall_get_sidebar( $sidebar = "" ) {

		/*====== Settings ======*/
		ob_start();

			dynamic_sidebar( $sidebar );

			$sidebar_content = ob_get_contents();

		ob_end_clean();

		$sidebar_content = trim( $sidebar_content );

		/*====== HTML Output ======*/
		$output = "";

		$output .= $sidebar_content;

		return $output;

	}

}

if( !function_exists( 'wonder_wall_services_post_type' ) ) {

	function wonder_wall_services_post_type() {

		$labels = array(
			'menu' => esc_html__( 'Services', 'wonder-wall' ),
			'singular_menu' => esc_html__( 'Service', 'wonder-wall' ),
			'menu_menu' => esc_html__( 'Services', 'wonder-wall' ),
			'parent_item_colon' => esc_html__( 'Parent Service:', 'wonder-wall' ),
			'all_items' => esc_html__( 'All Services', 'wonder-wall' ),
			'view_item' => esc_html__( 'View Service', 'wonder-wall' ),
			'add_new_item' => esc_html__( 'Add New Service Item', 'wonder-wall' ),
			'add_new' => esc_html__( 'Add New Service', 'wonder-wall' ),
			'edit_item' => esc_html__( 'Edit Service', 'wonder-wall' ),
			'update_item' => esc_html__( 'Update Service', 'wonder-wall' ),
			'search_items' => esc_html__( 'Search Service', 'wonder-wall' ),
			'not_found' => esc_html__( 'Not Service Found', 'wonder-wall' ),
			'not_found_in_trash' => esc_html__( 'Not Service Found in Trash', 'wonder-wall' ),
		);

		$args = array(
			'label' => esc_html__( 'Services', 'wonder-wall' ),
			'description' => esc_html__( 'Service post type description.', 'wonder-wall' ),
			'labels' => $labels,
			'supports' => array( 'title', 'comments', 'author', 'excerpt', 'thumbnail', 'revisions', 'editor', 'custom-fields' ),
			'show_in_rest' => true,
			'hierarchical' => false,
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'show_in_nav_menus' => true,
			'show_in_admin_bar' => true,
			'menu_position' => 20,
			'menu_icon' => 'dashicons-cover-image',
			'can_export' => true,
			'has_archive' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'capability_type' => 'post',
		);

		register_post_type( 'service', $args );

	}
	add_action( 'init', 'wonder_wall_services_post_type', 3 );

}


function custom_service_taxonomy() {
    $labels = array(
        'name'              => __('Service Categories'),
        'singular_name'     => __('Service Category'),
        'search_items'      => __('Search Categories'),
        'all_items'         => __('All Categories'),
        'parent_item'       => __('Parent Category'),
        'parent_item_colon' => __('Parent Category:'),
        'edit_item'         => __('Edit Category'),
        'update_item'       => __('Update Category'),
        'add_new_item'      => __('Add New Category'),
        'new_item_name'     => __('New Category Name'),
        'menu_name'         => __('Categories'),
    );

    $args = array(
        'hierarchical'      => true, // true: Kategori, false: Etiket
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'service-category'),
        'show_in_rest'      => true, // Gutenberg desteği
    );

    register_taxonomy('service_category', array('service'), $args);
}

add_action('init', 'custom_service_taxonomy');



function eb_header_qb_search(){ 
	?>
	<div class="eb-search">
		<a>
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" enable-background="new 0 0 50 50">
				<path fill="currentColor" d="M48.8 46.2l-9.2-9.4c3.5-3.9 5.7-9.1 5.7-14.7C45.3 9.9 35.4 0 23.2 0s-22 9.9-22 22.1 9.9 22.1 22 22.1c4.4 0 8.5-1.3 12-3.6l9.5 9.5 4.1-3.9zM7.1 22.1c0-8.9 7.2-16.2 16.2-16.2 8.9 0 16.2 7.3 16.2 16.2s-7.3 16.2-16.2 16.2c-9-.1-16.2-7.3-16.2-16.2z"></path>
			</svg>
		</a>
	</div><!-- eb-search -->
	<?php
}

function eb_header_qb_search_detail(){ 
	?>
	<div class="eb-search-holder">
		<div class="container">
			<div class="eb-search-close">
				<a><span class="eb-close"><i class="fa fa-close"></i></span></a>
			</div><!-- eb-search-close -->
			<?php get_search_form(); ?>
			<span class="eb-search-message"><?php echo esc_html('Input your search keywords and press Enter.', 'evonews'); ?></span>
		</div><!-- container -->
	</div><!-- eb-search-holder -->
	<?php
}

//POST NOT FOUND
function post_content_none(){
	?>
		<div class="eb-not-found">
			<div class="container">
				<div class="eb-not-found-inner">
					<h2 class="eb-subtitle"><?php echo esc_html__('Nothing Found', 'evonews'); ?></h2>
					<span><?php echo esc_html('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'evonews'); ?></span>
				</div><!-- eb-not-found-inner -->

				<div class="eb-not-found-form">
					<span><?php echo esc_html__('If you are not happy with the results, please do another search', 'evonews');?></span>
					<?php get_search_form(); ?>
				</div><!-- eb-not-found-form -->
			</div><!-- container -->
		</div><!-- eb-not-found -->
	<?php
}