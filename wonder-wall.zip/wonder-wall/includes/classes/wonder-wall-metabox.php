<?php
function elegant_embrace_meta_boxes( $meta_boxes ) {



    /*======
    *
    * Video single detail
    *
    ======*/

    $meta_boxes[] = array(
        /*====== Settings ======*/
        'id' => 'post-video-settings',
        'title' => esc_html__( 'Video Post Settings', 'wonder-wall' ),
        'post_types' => 'post',
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'center',
        'tab_wrapper' => false,

        'fields' => array(
            array(
                'name' => esc_html__( 'Video link', 'wonder-wall' ),
                'desc' => esc_html__( 'Enter a link for the video.', 'wonder-wall' ),
                'id' => 'video-post-link',
                'type'  => 'textarea',
            )
            ),
    );



    $meta_boxes[] = array(
        /*====== Settings ======*/
        'id' => 'page-header',
        'title' => esc_html__( 'Page Header On Off', 'wonder-wall' ),
        'post_types' => array('page', 'product', 'post'),
        'context' => 'normal',
        'priority' => 'low',
        'tab_style' => 'left',
        'tab_wrapper' => true,

        /*====== Fields ======*/
        'fields' => array(
            array(
                'type' => 'button_group',
                'id' => 'wonder-wall-header-position',
                'name' => esc_html__( 'Header Position', 'wonder-wall' ),
                'inline' => true,
                'std' => 'default',
                'options' => array(
                    'default' => esc_html__( 'Default', 'wonder-wall' ),
                    'absolute' => esc_html__( 'Absolute', 'wonder-wall' ),
                ),
            ),
            array(
                'type' => 'button_group',
                'id' => 'wonder-wall-sticky-header',
                'name' => esc_html__( 'Sticky Header', 'wonder-wall' ),
                'tab' => 'header',
                'inline' => true,
                'std' => 'default',
                'options' => array(
                    'default' => esc_html__( 'Default', 'wonder-wall' ),
                    '1' => esc_html__( 'Show', 'wonder-wall' ),
                    '0' => esc_html__( 'Hide', 'wonder-wall' ),
                ),
            ),

            array(
                'type' => 'button_group',
                'id' => 'wonder-wall-header-seperator',
                'name' => esc_html__( 'Header Seperator', 'wonder-wall' ),
                'tab' => 'header',
                'inline' => true,
                'std' => 'default',
                'options' => array(
                    '1' => esc_html__( 'Show', 'wonder-wall' ),
                    '0' => esc_html__( 'Hide', 'wonder-wall' ),
                ),
            ),
            array(
                'type' => 'button_group',
                'id' => 'wonder-wall-page-layout',
                'name' => esc_html__( 'Page Layout', 'wonder-wall' ),
                'inline' => true,
                'std' => 'full-container',
                'options' => array(
                    'container' => esc_html__( 'Container', 'wonder-wall' ),
                    'full-container' => esc_html__( 'Full Container', 'wonder-wall' ),
                ),
            ),
        ),
    );

    $meta_boxes[] = [
        'id' => 'breadcrumb_switcher',
        'title' => 'Breadcrumb Visibility',
        'post_types' => ['product'],
        'fields' => [
            [
                'name' => 'Show Breadcrumb',
                'id'   => 'show_breadcrumb',
                'type' => 'checkbox',
                'desc' => 'Enable to display breadcrumb on product page.',
                'std'  => 1,
            ],
        ],
    ];


    return $meta_boxes;

}


add_filter( 'rwmb_meta_boxes', 'elegant_embrace_meta_boxes' );

