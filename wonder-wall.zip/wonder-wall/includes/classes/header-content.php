<?php

if( !function_exists( 'wonder_wall_sticky_header' ) ) {

function wonder_wall_sticky_header() {

    $logo_image = get_theme_mod('logo-image');
    $register_text = get_theme_mod('header-register-text');
    $social_arrays  = get_theme_mod( 'repeater_setting');
    $logo_image_switcher = get_theme_mod('logo on/off', 'on');
    $sidebar_copyright_text = get_theme_mod('sidebar-copyright-text');
    $sidebar_switcher = get_theme_mod('sidebar on/off');
    $header_sticky_switcher = get_theme_mod('header-sticky','1');


    $header_search = get_theme_mod('header-search', '1');
    $header_favourite = get_theme_mod('header-favourite', '1');
    $header_shop = get_theme_mod('header-shop', '1');


    if( function_exists( 'rwmb_meta' ) ) {

        $header_sticky = rwmb_meta( 'wonder-wall-sticky-header' );
    }
    else {
        $header_sticky = '';
    }
    
        
    if(  $header_sticky !== "default" and !empty(  $header_sticky ) ) {
        
        $header_sticky_switcher = esc_attr(  $header_sticky );

    }


$output = '';

if($header_sticky_switcher == '1') {
    $output .= '<div class="eb-header eb-style-1 eb-fixed eb-sticky-header">';
        $output .= '<div class="eb-topbar">';
            $output .= '<div class="container">';
                $output .= '<div class="eb-topbar-inner">';
                    $output .= '<div class="eb-item-left">';
                        if(!empty($register_text)) {
                            $output .= '<a href="'. get_home_url() .'">'.  esc_attr($register_text) .'</a>';
                        }
                    $output .= '</div>';
                    $output .= '<div class="eb-item-right">';
                        if($header_search == '1') {
                            $output .='<div class="eb-search">';
                            $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M15.4 8.19987C15.4 4.22349 12.1764 1 8.2 1C4.22355 1 1 4.22349 1 8.19987C1 12.1762 4.22355 15.3997 8.2 15.3997C12.1764 15.3997 15.4 12.1762 15.4 8.19987Z" stroke="#323E48" stroke-width="1.5" stroke-linejoin="round"/><path d="M13.3999 13.4001L16.9999 17.0001" stroke="#323E48" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    $output .= '</div>';
                            $output .= eb_header_qb_search_detail();
                        }
                        if($header_favourite == '1') {
                            $output .='<div class="eb-favourite">';
                                $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none"><path d="M8.56185 2.45414L9.16211 3.25547L9.76237 2.45414C10.5363 1.42095 11.7761 0.75 13.1581 0.75C15.5043 0.75 17.4121 2.65878 17.4121 5.02472C17.4121 6.01271 17.2544 6.92357 16.9806 7.76887L16.979 7.77376C16.3219 9.85087 14.9712 11.5355 13.4987 12.7994C12.023 14.0662 10.4681 14.8728 9.47879 15.209L9.47878 15.2089L9.47077 15.2118C9.42291 15.2286 9.31106 15.25 9.16211 15.25C9.01315 15.25 8.90131 15.2286 8.85345 15.2118L8.85346 15.2117L8.84542 15.209C7.85615 14.8728 6.30123 14.0662 4.82548 12.7994C3.35299 11.5355 2.00236 9.85087 1.34517 7.77376L1.34519 7.77375L1.34361 7.76887C1.06979 6.92357 0.912109 6.01271 0.912109 5.02472C0.912109 2.65878 2.81994 0.75 5.16611 0.75C6.54814 0.75 7.7879 1.42095 8.56185 2.45414Z" stroke="#323E48" stroke-width="1.5"/></svg>';
                                $output .= '<div class="eb-badge">'.   WC()->cart->get_cart_contents_count() .'</div>';
                            $output .= '</div>';
                        }
                        if($header_shop == '1') {
                            $output .='<div class="eb-shop">';
                                $output .= '<a href="'.wc_get_checkout_url() .'">';
                                    $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M5.04785 5.53125V4.75492C5.04785 2.95418 6.70256 1.18544 8.75951 1.01737C11.2096 0.809287 13.2757 2.49799 13.2757 4.60286V5.70732" stroke="#323E48" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.4195 17.0001H11.9047C15.5798 17.0001 16.238 15.7115 16.43 14.1429L17.1157 9.34088C17.3625 7.38807 16.7226 5.79541 12.8189 5.79541H5.5053C1.60166 5.79541 0.961719 7.38807 1.20855 9.34088L1.89421 14.1429C2.08619 15.7115 2.74441 17.0001 6.4195 17.0001Z" stroke="#323E48" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.3578 8.99685H12.3661" stroke="#323E48" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.95745 8.99685H5.96566" stroke="#323E48" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                                    $output .= '<div class="eb-badge">'.   WC()->cart->get_cart_contents_count() .'</div>';
                                $output .= '</a>';
                            $output .= '</div>';
                        }
                    $output .= '</div>';
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';
        $output .= '<div class="eb-bottom">';
            $output .= '<div class="container">';
                $output .= '<div class="eb-bottom-inner">';
                    $output .= '<div class="eb-item-group eb-seperator">';
                        $output .= ' <div class="eb-item eb-menu eb-menu-left">';
                            $output .= wp_nav_menu(
                                array(
                                    'theme_location' => 'primary',
                                    'container' => 'div',
                                    'menu_class' => 'eb-nav-menu',
                                    'fallback_cb' => 'wonder_wall_walker::fallback',
                                    'walker' => new wonder_wall_walker(),
                                    'depth' => '4',
                                    'echo' => false,
                                )
                            );
                        $output .= '</div>';
                        if($logo_image_switcher == "on") {
                            $output .= '<div class="eb-item eb-logo">';
                                $output .= '<a href="'. get_home_url() .'" title="'. esc_attr($logo_text) .'">';
                                    $output .= '<img src="'. esc_url($logo_image) .'">';
                                $output .= '</a>';
                            $output .= '</div>';
                        }
                        $output .= ' <div class="eb-item eb-menu eb-menu-right">';
                            $output .= wp_nav_menu(
                                array(
                                    'theme_location' => 'primary',
                                    'container' => 'div',
                                    'menu_class' => 'eb-nav-menu',
                                    'fallback_cb' => 'wonder_wall_walker::fallback',
                                    'walker' => new wonder_wall_walker(),
                                    'depth' => '4',
                                    'echo' => false,
                                )
                            );
                        $output .= '</div>';
                    $output .= '</div>';

                    if($sidebar_switcher == 'on') {
                        $output .= '<nav class="navbar navbar-expand-lg navbar-light" role="navigation">';
                            $output .= '<div class="icon ml-auto" id="navbarSideButton" type="button">';
                                $output .= '<svg viewBox="0 0 12 10" class="hamburger" height="50px" width="25px"><path d="M10,2 L2,2" class="upper"/><path d="M2,5 L10,5" class="middle"/><path d="M10,8 L2,8" class="lower"/> </svg>';
                            $output .= '</div>';
                        $output .= '</nav>';
                        $output .= '<div class="side-drawer" id="side-drawer">';
                            $output .= '<div class="side-drawer-inner">';
                                $output .= '<div class="eb-side-drawer eb-logo">';
                                    $output .= ' <a href="'. get_home_url() .'" title="'. esc_attr($logo_text) .'">';
                                        if($logo_image_switcher == 'on') {
                                            $output .= '<img src="'. esc_url($logo_image) .'">';
                                        }
                                    $output .= '</a>';
                                $output .= '</div>';
                                $output .='<div class="eb-side-info-bottom">';
                                    $output .='<div class="navigation">';
                                        $output .='<div class="eb-item eb-mobile-menu">';
                                            $output .= wp_nav_menu(
                                                array(
                                                    'theme_location' => 'mobile',
                                                    'container' => 'div',
                                                    'menu_class' => 'eb-nav-menu navbar-side',
                                                    'menu_id' => 'navbarSide',
                                                    'fallback_cb' => 'elegant_embrace_walker::fallback',
                                                    'walker' => new elegant_mobile_embrace_walker(),
                                                    'depth' => '4',
                                                    'echo' => false,
                                                )
                                            );
                                        $output .= '</div>';
                                        $output .= '<div class="eb-item eb-mobile-social">';
                                            $output .= '<ul class="eb-social">';
                                                foreach ($social_arrays as $key => $value) : 
                                                    $output .= '<li><a href="'. esc_url($value['link_url']) .'" target = '. esc_attr($value['link_target']).'>';
                                                        if($value['select'] == 'facebook') {
                                                            $output .= '<span><i class="fa-brands fa-'. esc_attr($value['select']).'-f"></i></span>';
                                                        }
                                                        else {
                                                            $output .= '<span><i class="fa-brands fa-'. esc_attr($value['select']).'"></i></span>';
                                                        }
                                                    $output .='</a></li>';
                                                endforeach;
                                            $output .= '</ul>';
                                        $output .= '</div>';
                                        $output .= '<div class="eb-mobile-copyright-text">';
                                            $output .= '<div class="eb-mobile-copyright-text">';
                                                $output .= '<p>'. esc_attr($sidebar_copyright_text) .'</p>';
                                            $output .= '</div>';
                                    $output .= '</div>';
                                $output .= '</div>';
                            $output .= '</div>';
                        $output .= '</div>';
                    }
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';
    $output .= '</div>';
}
return $output;
}



if( !function_exists( 'wonder_wall_header' ) ) {

    function wonder_wall_header() {
        $logo_image = get_theme_mod('logo-image');
        $register_text = get_theme_mod('header-register-text');
        $social_arrays  = get_theme_mod( 'social_repeater_setting');
        $logo_image_switcher = get_theme_mod('logo on/off', 'on');
        $sidebar_copyright_text = get_theme_mod('sidebar-copyright-text');
        $sidebar_switcher = get_theme_mod('sidebar on/off');
        $header_sticky_switcher = get_theme_mod('header-sticky','1');


        $header_search = get_theme_mod('header-search', '1');
        $header_favourite = get_theme_mod('header-favourite', '1');
        $header_shop = get_theme_mod('header-shop', '1');

        $header_absolute_switcher = get_theme_mod('header-absolute','default');

        if( function_exists( 'rwmb_meta' ) ) {

            $header_position = rwmb_meta( 'wonder-wall-header-position' );
            $header_seperator_meta = rwmb_meta( 'wonder-wall-header-seperator' );

        }
        else {
            $header_position = '';
            $header_seperator_meta = '';
        }
        
            
        if( $header_position !== "default" ) {
        
            $header_absolute_switcher = esc_attr(  $header_position );
            // $header_position = $header_absolute_switcher ;
        }

        if( $header_seperator_meta !== "1" ) {
        
            $header_seperator = esc_attr(  $header_seperator_meta );
            $header_seperator_meta =  $header_seperator;
        }

        
    
    $output = '';
    if($header_absolute_switcher == 'absolute') {
        $output .= '<div class="eb-header eb-style-1 eb-absolute">';
    }
    else {
        $output .= '<div class="eb-header eb-style-1">';
    }
    $output .= '<div class="eb-topbar">';
        $output .= '<div class="container">';
            $output .= '<div class="eb-topbar-inner">';
                $output .= '<div class="eb-item-left">';
                    if(!empty($register_text)) {
                        $output .= '<a href="'. get_home_url() .'">'.  esc_attr($register_text) .'</a>';
                    }
                $output .= '</div>';
                $output .= '<div class="eb-item-right">';
                    // if($header_search == '1') {
                    //     $output .='<div class="eb-search">';
                    //         $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M15.4 8.19987C15.4 4.22349 12.1764 1 8.2 1C4.22355 1 1 4.22349 1 8.19987C1 12.1762 4.22355 15.3997 8.2 15.3997C12.1764 15.3997 15.4 12.1762 15.4 8.19987Z" stroke="#323E48" stroke-width="1.5" stroke-linejoin="round"/><path d="M13.3999 13.4001L16.9999 17.0001" stroke="#323E48" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    //     $output .= '</div>';
                    //     $output .= eb_header_qb_search_detail();
                    // }
                    if($header_search == '1') {
                        $output .= '<div class="eb-item eb-search">';
                            $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M15.4 8.19987C15.4 4.22349 12.1764 1 8.2 1C4.22355 1 1 4.22349 1 8.19987C1 12.1762 4.22355 15.3997 8.2 15.3997C12.1764 15.3997 15.4 12.1762 15.4 8.19987Z" stroke="#323E48" stroke-width="1.5" stroke-linejoin="round"/><path d="M13.3999 13.4001L16.9999 17.0001" stroke="#323E48" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    $output .= '</div>';
                        $output .= eb_header_qb_search_detail();
                    }
                    if($header_favourite == '1') {
                        $wishlist_page_url = get_permalink(get_option('yith_wcwl_wishlist_page_id'));
                        $output .='<div class="eb-favourite">';
                            $output .= '<a href="'. esc_url( $wishlist_page_url) .'">';
                                $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none"><path d="M8.56185 2.45414L9.16211 3.25547L9.76237 2.45414C10.5363 1.42095 11.7761 0.75 13.1581 0.75C15.5043 0.75 17.4121 2.65878 17.4121 5.02472C17.4121 6.01271 17.2544 6.92357 16.9806 7.76887L16.979 7.77376C16.3219 9.85087 14.9712 11.5355 13.4987 12.7994C12.023 14.0662 10.4681 14.8728 9.47879 15.209L9.47878 15.2089L9.47077 15.2118C9.42291 15.2286 9.31106 15.25 9.16211 15.25C9.01315 15.25 8.90131 15.2286 8.85345 15.2118L8.85346 15.2117L8.84542 15.209C7.85615 14.8728 6.30123 14.0662 4.82548 12.7994C3.35299 11.5355 2.00236 9.85087 1.34517 7.77376L1.34519 7.77375L1.34361 7.76887C1.06979 6.92357 0.912109 6.01271 0.912109 5.02472C0.912109 2.65878 2.81994 0.75 5.16611 0.75C6.54814 0.75 7.7879 1.42095 8.56185 2.45414Z" stroke="#323E48" stroke-width="1.5"/></svg>';
                                $output .= '<div class="eb-badge">'.   yith_wcwl_count_products() .'</div>';
                            $output .= '</a>';
                        $output .= '</div>';
                    }
                    if($header_shop == '1') {
                        $output .='<div class="eb-shop">';
                            $output .= '<a href="'.wc_get_checkout_url() .'">';
                                $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M5.04785 5.53125V4.75492C5.04785 2.95418 6.70256 1.18544 8.75951 1.01737C11.2096 0.809287 13.2757 2.49799 13.2757 4.60286V5.70732" stroke="#323E48" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.4195 17.0001H11.9047C15.5798 17.0001 16.238 15.7115 16.43 14.1429L17.1157 9.34088C17.3625 7.38807 16.7226 5.79541 12.8189 5.79541H5.5053C1.60166 5.79541 0.961719 7.38807 1.20855 9.34088L1.89421 14.1429C2.08619 15.7115 2.74441 17.0001 6.4195 17.0001Z" stroke="#323E48" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.3578 8.99685H12.3661" stroke="#323E48" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.95745 8.99685H5.96566" stroke="#323E48" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                                $output .= '<div class="eb-badge">'.   WC()->cart->get_cart_contents_count() .'</div>';
                            $output .= '</a>';
                        $output .= '</div>';
                    }
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';
    $output .= '</div>';
    $output .= '<div class="eb-bottom">';
        $output .= '<div class="container">';
            $output .= '<div class="eb-bottom-inner">';
                    $output .= '<div class="eb-item-group eb-seperator">';
                        $output .= ' <div class="eb-item eb-menu eb-menu-left">';
                            $output .= wp_nav_menu(
                                array(
                                    'theme_location' => 'primary-left',
                                    'container' => 'div',
                                    'menu_class' => 'eb-nav-menu',
                                    'fallback_cb' => 'wonder_wall_walker::fallback',
                                    'walker' => new wonder_wall_walker(),
                                    'depth' => '4',
                                    'echo' => false,
                                )
                            );
                        $output .= '</div>';
                        if($logo_image_switcher == "on") {
                            $output .= '<div class="eb-item eb-logo">';
                                $output .= '<a href="'. get_home_url() .'" title="'. esc_attr($logo_text) .'">';
                                    $output .= '<img src="'. esc_url($logo_image) .'">';
                                $output .= '</a>';
                            $output .= '</div>';
                        }
                        $output .= ' <div class="eb-item eb-menu eb-menu-right">';
                            $output .= wp_nav_menu(
                                array(
                                    'theme_location' => 'primary-right',
                                    'container' => 'div',
                                    'menu_class' => 'eb-nav-menu',
                                    'fallback_cb' => 'wonder_wall_walker::fallback',
                                    'walker' => new wonder_wall_walker(),
                                    'depth' => '4',
                                    'echo' => false,
                                )
                            );
                        $output .= '</div>';
                    $output .= '</div>';


                    if($sidebar_switcher == 'on') {
                        $output .= '<nav class="navbar navbar-expand-lg navbar-light" role="navigation">';
                            $output .= '<div class="icon ml-auto" id="navbarSideButton" type="button">';
                                $output .= '<svg viewBox="0 0 12 10" class="hamburger" height="50px" width="25px"><path d="M10,2 L2,2" class="upper"/><path d="M2,5 L10,5" class="middle"/><path d="M10,8 L2,8" class="lower"/> </svg>';
                            $output .= '</div>';
                        $output .= '</nav>';
                        $output .= '<div class="side-drawer" id="side-drawer">';
                            $output .= '<div class="side-drawer-inner">';
                                $output .= '<div class="eb-side-drawer eb-logo">';
                                    $output .= ' <a href="'. get_home_url() .'" title="'. esc_attr($logo_text) .'">';
                                        if($logo_image_switcher == 'on') {
                                            $output .= '<img src="'. esc_url($logo_image) .'">';
                                        }
                                    $output .= '</a>';
                                $output .= '</div>';
                                $output .='<div class="eb-side-info-bottom">';
                                    $output .='<div class="navigation">';
                                        $output .='<div class="eb-item eb-mobile-menu">';
                                            $output .= wp_nav_menu(
                                                array(
                                                    'theme_location' => 'mobile',
                                                    'container' => 'div',
                                                    'menu_class' => 'eb-nav-menu navbar-side',
                                                    'menu_id' => 'navbarSide',
                                                    'fallback_cb' => 'elegant_embrace_walker::fallback',
                                                    'walker' => new elegant_mobile_embrace_walker(),
                                                    'depth' => '4',
                                                    'echo' => false,
                                                )
                                            );
                                        $output .= '</div>';
                                        $output .= '<div class="eb-item eb-mobile-social">';
                                            $output .= '<ul class="eb-social">';
                                                foreach ($social_arrays as $key => $value) : 
                                                    $output .= '<li><a href="'. esc_url($value['link_url']) .'" target = '. esc_attr($value['link_target']).'>';
                                                        if($value['select'] == 'facebook') {
                                                            $output .= '<span><i class="fa-brands fa-'. esc_attr($value['select']).'-f"></i></span>';
                                                        }
                                                        else {
                                                            $output .= '<span><i class="fa-brands fa-'. esc_attr($value['select']).'"></i></span>';
                                                        }
                                                    $output .='</a></li>';
                                                endforeach;
                                            $output .= '</ul>';
                                        $output .= '</div>';
                                        $output .= '<div class="eb-mobile-copyright-text">';
                                            $output .= '<div class="eb-mobile-copyright-text">';
                                                $output .= '<p>'. esc_attr($sidebar_copyright_text) .'</p>';
                                            $output .= '</div>';
                                    $output .= '</div>';
                                $output .= '</div>';
                            $output .= '</div>';
                        $output .= '</div>';
                    }
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';

    return $output;
    }
}
}
?>