<?php
require_once get_template_directory() . '/includes/plugins/class-tgm-plugin-activation.php';

if( !function_exists( 'wonder_wall_register_required_plugins' ) ) {

	function wonder_wall_register_required_plugins() {

		$plugins = array(
			array(
				'slug' => 'wonder-wall-core',
				'name' => esc_html__( 'Wonder Wall Theme Core', 'wonder-wall' ),
				'source' => get_template_directory() . '/includes/plugins/wonder_wall_page_builder.zip',
				'version' => '1.0.0',
				'required' => true, 
				'force_activation' => false,
			),
			array(
				'slug' => 'ameliabooking',
				'name' => esc_html__( 'Booking for Appointments and Events Calendar – Amelia', 'wonder-wall' ),
				'required' => true, 
				'force_activation' => false,
			),
			array(
				'slug' => 'elementor',
				'name' => esc_html__( 'Elementor', 'wonder-wall' ),
				'required' => true,
				'force_activation' => false,
			),
			array(
				'slug' => 'kirki',
				'name' => esc_html__( 'Kirki', 'wonder-wall' ),
				'required' => true,
				'force_activation' => false,
			),
			array(
				'slug' => 'meta-box',
				'name' => esc_html__( 'Meta Box', 'wonder-wall' ),
				'required' => true,
				'force_activation' => false,
			),
			array(
				'slug' => 'woocommerce',
				'name' => esc_html__( 'WooCommerce', 'wonder-wall' ),
				'required' => false,
				'force_activation' => false,
			),
			array(
				'slug' => 'yith-woocommerce-wishlist',
				'name' => esc_html__( 'YITH WooCommerce Wishlist', 'wonder-wall' ),
				'required' => false,
				'force_activation' => false,
			),
			
			array(
				'slug' => 'contact-form-7',
				'name' => esc_html__( 'Contact Form 7', 'wonder-wall' ),
				'required' => false,
				'force_activation' => false,
			),
			array(
				'slug' => 'mailchimp-for-wp',
				'name' => esc_html__( 'MailChimp for WordPress', 'wonder-wall' ),
				'required' => false,
				'force_activation' => false,
			),
			array(
				'name'     => esc_html__('Easy Google Fonts', 'wonder-wall'),
				'slug'     => 'easy-google-fonts',
				'required' => true,
			),
		);

		$config = array(
			'id' => 'wonder-wall',
			'default_path' => '',
			'menu' => 'tgmpa-install-plugins',
			'has_notices' => true,
			'dismissable' => true,
			'dismiss_msg' => '',
			'is_automatic' => true,
			'message' => '',
		);

		tgmpa( $plugins, $config );

	}
	add_action( 'tgmpa_register', 'wonder_wall_register_required_plugins' );

}