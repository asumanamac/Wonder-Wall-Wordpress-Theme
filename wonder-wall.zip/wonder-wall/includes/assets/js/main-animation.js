document.addEventListener('DOMContentLoaded', function () {
    // Debug: animationSettings kontrolü
    console.log("animationSettings:", animationSettings);

    if (typeof animationSettings !== 'undefined' && animationSettings.enabled == false) {
        console.log("Animasyonlar devre dışı bırakıldı.");
        document.body.classList.add("animations-disabled");
        disableGSAPAnimations(); // Animasyonları devre dışı bırak
    } else {
        console.log("Animasyonlar aktif.");
        document.body.classList.remove("animations-disabled");
        enableGSAPAnimations(); // Animasyonları yeniden başlat
    }
});

// Animasyonları durdurma fonksiyonu
function disableGSAPAnimations() {
    gsap.killTweensOf('*'); // Tüm tween'leri durdur

    ScrollTrigger.getAll().forEach(trigger => {
        trigger.kill(); // ScrollTrigger animasyonlarını öldür
    });

    document.querySelectorAll('.hero-animation, .eb-animation, .eb-arrow-animation').forEach(el => {
        el.style.opacity = "1";
        el.style.transform = "none";
    });

    console.log("Tüm GSAP animasyonları durduruldu.");
}

// Animasyonları yeniden başlatma fonksiyonu
function enableGSAPAnimations() {
    console.log("Animasyonlar yeniden başlatılıyor...");
    setupGSAPAnimations();
}

// GSAP animasyonlarını kurma
function setupGSAPAnimations() {
    // GSAP eklentileri
    gsap.registerPlugin(ScrollTrigger);


    // Section fade animasyonları
    const sections = gsap.utils.toArray('.eb-animation');
    if (sections.length > 0) {
        sections.forEach(section => {
            gsap.from(section, {
                scrollTrigger: {
                    trigger: section,
                    start: "top 80%",
                    end: "top 20%",
                    scrub: 0.5,
                },
                opacity: 0,
                y: 50,
                duration: .5,
                ease: "sine.inOut"
            });
        });
    } else {
        console.log('Animasyon için uygun öğe bulunamadı.');
    }
    
    gsap.utils.toArray('.eb-arrow-animation').forEach(arrow => {
        gsap.to(arrow, {
            y: 20,
            duration: 1,
            repeat: -1,
            yoyo: true,
            ease: "power1.inOut"
        });
    });

}

// Hover animasyonları
const buttons = document.querySelectorAll('.eb-button.eb-style-1 a');
buttons.forEach(button => {
    const arrow = button.querySelector('svg');
    const buttonText = button.querySelector('.button-text');

    // Hover üzerine geldiğinde metni sola ve ok simgesini sağa kaydır
    button.addEventListener('mouseenter', () => {
        gsap.to(arrow, {
            opacity: 1,
            x: 5, // Sağ kayma hareketi
            duration: 0.1,
            ease: "power1.out"
        });

        gsap.to(buttonText, {
            x: -20, // Metni sola kaydır
            duration: 0.1,
            ease: "power1.out"
        });
    });

    // Hover'dan çıkıldığında metni ve ok simgesini geri getir
    button.addEventListener('mouseleave', () => {
        gsap.to(arrow, {
            opacity: 0,
            x: 0, // Ok simgesini orijinal pozisyona döndür
            duration: 0.1,
            ease: "power1.out"
        });

        gsap.to(buttonText, {
            x: 0, // Metni başlangıç pozisyonuna döndür
            duration: 0.1,
            ease: "power1.out"
        });
    });
});


// Hover animasyonları
const buttons2 = document.querySelectorAll('.eb-button.eb-style-2 a');
buttons2.forEach(button => {
    const arrow = button.querySelector('svg');

    // Hover üzerine geldiğinde metni sola ve ok simgesini sağa kaydır
    button.addEventListener('mouseenter', () => {
        gsap.to(arrow, {
            opacity: 1,
            x: 2, // Sağ kayma hareketi
            duration: 0.1,
            ease: "power1.out"
        });

    });

    // Hover'dan çıkıldığında metni ve ok simgesini geri getir
    button.addEventListener('mouseleave', () => {
        gsap.to(arrow, {
            opacity: 0,
            x: 0, // Ok simgesini orijinal pozisyona döndür
            duration: 0.1,
            ease: "power1.out"
        });

    });
});

