var upper = document.getElementsByClassName('upper');
var middle = document.getElementsByClassName('middle');
var lower = document.getElementsByClassName('lower');

var tl = new TimelineMax({
  paused: true,
  reversed: true
});

tl.to(upper, 0.5, {stroke: "#000", attr: {d: "M8,2 L2,8"}, x: 1, ease:Power2.easeInOut}, 'start'); //Hamburger icon top
tl.to(middle, 0.5, {autoAlpha: 0}, 'start'); //Hamburger icon middle
tl.to(lower, 0.5, {stroke: "#000", attr: {d: "M8,8 L2,2"}, x: 1, ease:Power2.easeInOut}, 'start'); //Hamburger icon bottom
tl.to('.side-drawer', 0.3, {x: 0}, '-=0.3'); //Nav drawer slide in
tl.staggerFrom('.eb-side-drawer.eb-logo', 0.2, {x:200, opacity: 0, ease:Power1.easeOut}, 0.02); //Nav item stagger
tl.staggerFrom('.navbar-side-item', 0.3, {x:200, opacity: 0, ease:Power1.easeOut}, 0.05); //Nav item stagger
tl.staggerFrom('.eb-mobile-social', 0.4, {x:200, opacity: 0, ease:Power1.easeOut}, 0.02); //Nav item stagger
tl.staggerFrom('.eb-mobile-copyright-text', 0.5, {x:200, opacity: 0, ease:Power1.easeOut}, 0.02); //Nav item stagger


tl.reversed(true);

document.getElementById('navbarSideButton').addEventListener('click', function() {
  tl.reversed( !tl.reversed());
  if (tl.reversed())
    tl.reverse();
  else
    tl.play();
});

$('.eb-mobile-dropdown.mobile ul').hide();
$(".eb-mobile-dropdown a").click(function () {
	$(this).parent(".eb-mobile-dropdown").children("ul").slideToggle("200");
  $(this).find(".right i").toggleClass("fa-chevron-up fa-chevron-down",500);

});

	// === Swiper ==================================== //
	function gt_slider() {
		$('.eb-slider-container, .eb-carousel-container').each( function(index, element) {
			var swiperDatas = $(this),
				var_speed = $(this).data('eb-speed'),
				var_direction = $(this).data('eb-direction'),
				var_auto_height = $(this).data('eb-auto-height'),
				var_effect = $(this).data('eb-effect'),
				var_slides_per_view = $(this).data('eb-item'),
				var_slides_per_column = $(this).data('eb-item-column'),
				var_slides_per_group = $(this).data('eb-item-group'),
				var_space_between = $(this).data('eb-item-space'),
				var_centered_slides = $(this).data('eb-centered-slides'),
				var_grab_cursor = $(this).data('eb-grab-cursor'),
				var_free_mode = $(this).data('eb-free-mode'),
				var_loop = $(this).data('eb-loop'),
				var_lazy = $(this).data('eb-lazy-loading'),
				var_pag = $(this).find('.eb-slider-pagination, .eb-carousel-pagination'),
				var_parallax = $(this).data('eb-parallax'),
				var_thumbs = $(this).data('eb-thumbs');

			if( var_centered_slides == true ) {

				var_slides_per_group = 1;

			}

			if (var_thumbs == true){
				var sliderThumbnail = new Swiper('.eb-slider-thumbs', {
					slidesPerView: 4,
					freeMode: true,
					loop: false,
					watchSlidesVisibility: true,
					watchSlidesProgress: true,
					slideToClickedSlide: false,
				});
			}

			var swiper = new Swiper(element, {
				speed: var_speed,
				direction: var_direction,
				setWrapperSize: true,
				autoHeight: var_auto_height,
				spaceBetween: var_space_between,
				slidesPerView: var_slides_per_view,
				slidesPerColumn: var_slides_per_column,
				slidesPerGroup: var_slides_per_group,
				centeredSlides: var_centered_slides,
				grabCursor: var_grab_cursor,
				freeMode: var_free_mode,
				loop: var_loop,
				lazy: {
					loadPrevNext: var_lazy,
					loadPrevNextAmount: 1,
					loadOnTransitionStart: true,
					elementClass: 'eb-lazy',
					preloaderClass: 'eb-lazy-preloader',
				},
				parallax: var_parallax,
				simulateTouch: true,
				effect: var_effect,
				autoplay: {
					delay: 99999,
					disableOnInteraction: true,
				},
				coverflowEffect: {
					rotate: 50,
					stretch: 0,
					depth: 100,
					modifier: 1,
					slideShadows : true,
				},
				pagination: {
					el: '.eb-slider-pagination, .eb-carousel-pagination',
					type: 'bullets',
					clickable: true,
					renderBullet: function (index, className) {
						if (index <= 8){
							return '<span class="' + className + '"></span>';
						}
						else{
							return '<span class="' + className + '"></span>';
						}
					},
				},
				thumbs: {
					swiper: sliderThumbnail
				},
				navigation: {
					nextEl: '.eb-slider-next, .eb-carousel-next',
					prevEl: '.eb-slider-prev, .eb-carousel-prev',
				},
				breakpoints: {
					1350: {
						slidesPerView: var_slides_per_view,
						slidesPerGroup: var_slides_per_group,
					},
					1280: {
						slidesPerView: var_slides_per_view < 5 ? var_slides_per_view: 4,
						slidesPerGroup: var_slides_per_group < 5 ? var_slides_per_group: 4,
					},
					1198: {
						slidesPerView: var_slides_per_view < 4 ? var_slides_per_view: 3,
						slidesPerGroup: var_slides_per_group < 4 ? var_slides_per_group: 3,
					},
					991: {
						slidesPerView: var_slides_per_view < 3 ? var_slides_per_view: 2,
						slidesPerGroup: var_slides_per_group < 3 ? var_slides_per_group: 2,
					},
					480: {
						slidesPerView: var_slides_per_view < 2 ? var_slides_per_view: 1,
						slidesPerGroup: var_slides_per_group < 2 ? var_slides_per_group: 1,
					},
					375: {
						slidesPerView: var_slides_per_view < 2 ? var_slides_per_view: 1,
						slidesPerGroup: var_slides_per_group < 2 ? var_slides_per_group: 1,
					},
				}
			});

			swiper.controller.control = sliderThumbnail;

		});
	}
	jQuery(window).ready(function () {
		setTimeout(function () {
			gt_slider();
		}, 1);
	});


$('.counter').each(function() {
  var $this = $(this),
      countTo = $this.attr('data-count');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 3000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  

});




	/*====== SEARCH HOLDER ======*/
	function evoSearch() {
		var mainContainer = $('body'),
			headerHight = $('.eb-header').height(),
			SearchOne = $('.eb-search-holder'),
			openCtrl = $('.eb-search'),
			closeCtrl = $('.eb-search-close a'),
			inputSearch = $('.eb-search-holder .eb-search-form .search_input');

		if ($("body").hasClass("eb-sticky-header") == true) {
			SearchOne.css('top', '54px');
		} else {
			SearchOne.css('top', headerHight);
		}

		function init() {
			initEvents();	
		}

		function initEvents() {
			for (var i = 0; i < openCtrl.length; i++) {
				openCtrl[i].addEventListener('click', openSearch);
			}
			for (var i = 0; i < closeCtrl.length; i++) {
				closeCtrl[i].addEventListener('click', closeSearch);
			}
			document.addEventListener('keyup', function(ev) {
				// escape key.
				if( ev.keyCode == 27 ) {
					closeSearch();
				}
			});
		}

		function openSearch() {
			mainContainer.addClass('eb-search-active');
			setTimeout(function() {
				inputSearch.focus();
			}, 500);
		}

		function closeSearch() {
			mainContainer.removeClass('eb-search-active');
			inputSearch.blur();
			inputSearch.value = '';
		}

		init();
	}
	

		evoSearch();




	
	gsap.registerPlugin(ScrollTrigger);
	window.addEventListener('load', () => {
	gsap.utils.toArray('.animation-item').forEach(section => {
		gsap.fromTo(section, 
			{ opacity: 0, y: 50 }, // Başlangıç durumu
			{ 
				opacity: 1, 
				y: 0, 
				duration: .5, // Animasyon süresi
				ease: 'power3.out', // Animasyon eğrisi
				scrollTrigger: {
					trigger: section,
					start: 'top 80%',
					end: 'top 20%',
					toggleActions: 'play reverse play reverse',
					scrub: true,
					markers: false // Test etmek için true yapabilirsiniz
				}
			}
		);
		ScrollTrigger.refresh();
	});
});

document.addEventListener('DOMContentLoaded', function () {
    // Tüm resimleri seçin (ana resim + küçük resimler)
    const images = document.querySelectorAll('.woocommerce-product-gallery__image img');
    
    // İlk resmi ana resim olarak belirleyin
    const mainImage = images[0];

    // Diğer resimleri küçük resimler olarak belirleyin
    const thumbnails = Array.from(images).slice(1); // İlk resmi hariç tutarak küçük resimleri alıyoruz
	

    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function (e) {
            e.preventDefault();
            // Küçük resme tıklandığında ana resim kaynağını değiştir
            mainImage.src = this.src;
            mainImage.srcset = this.srcset; // Yüksek çözünürlük desteği için srcset'i güncelle
        });
    });
});

document.querySelectorAll('.product-image').forEach(function(image) {
    image.addEventListener('mouseenter', function() {
        const hoverActions = this.querySelector('.product-hover-actions');
        hoverActions.style.opacity = '1';
        hoverActions.style.visibility = 'visible';
    });

    image.addEventListener('mouseleave', function() {
        const hoverActions = this.querySelector('.product-hover-actions');
        hoverActions.style.opacity = '0';
        hoverActions.style.visibility = 'hidden';
    });
});


jQuery(document).ready(function ($) {
    // YITH Wishlist Kalp Tıklama Olayını Takip Et
    $(document).on('click', '.add_to_wishlist', function (e) {
        e.preventDefault();
        const button = $(this); // Tıklanan buton

        // Eğer ürün wishlistteyse, kaldır
        if (button.hasClass('exists')) {
            button.removeClass('exists'); // Sınıfı kaldır
            button.text('Add to Wishlist'); // Metni güncelle (isteğe bağlı)
            console.log('Favorilerden kaldırıldı');
        } else {
            // Ürünü favorilere ekle
            button.addClass('exists'); // Sınıf ekle
            button.text('Remove from Wishlist'); // Metni güncelle (isteğe bağlı)
            console.log('Favorilere eklendi');
        }
    });
});



document.addEventListener("DOMContentLoaded", function() {
    const productTitle = document.querySelector('.up-sells h2');

    if (productTitle) {
        productTitle.innerText = "Related Products";  // Başlığı değiştiren JavaScript kodu
    }
});



document.addEventListener('DOMContentLoaded', function () {
    const feedbackElements = document.querySelectorAll('.yith-wcwl-wishlistaddedbrowse .feedback');
    feedbackElements.forEach(feedbackElement => {
        feedbackElement.childNodes.forEach(node => {
            if (node.nodeType === Node.TEXT_NODE) {
                node.textContent = ''; // Metni temizler
            }
        });
    });


	const feedbackElements2 = document.querySelectorAll('.yith-wcwl-add-button a');
    feedbackElements2.forEach(feedbackElement => {
        feedbackElement.childNodes.forEach(node => {
            if (node.nodeType === Node.TEXT_NODE) {
                node.textContent = ''; // Metni temizler
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const backToTop = document.getElementById('back-to-top');

    // Sayfa kaydırıldığında butonu göster
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) { // 300px aşağı kaydırıldığında göster
            backToTop.style.display = 'block';
        } else {
            backToTop.style.display = 'none';
        }
    });

    // Butona tıklayınca yukarı kaydır
    backToTop.addEventListener('click', function(e) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
