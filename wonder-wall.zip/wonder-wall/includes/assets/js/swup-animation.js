document.addEventListener("DOMContentLoaded", function () {
    // Debug: animationSettings kontrolü
    console.log("animationSettings:", animationSettings);

    // Animasyon açık mı kontrol et
    if (typeof animationSettings !== 'undefined' && animationSettings.enabled == true) {
        // Sayfa içeriğini başlangıçta gizle
        gsap.set("body", { opacity: 0 });

        // Sayfa açılış animasyonu
        gsap.to("body", {
            opacity: 1,
            duration: 1.5, // Animasyon süresi
            ease: "power4.out", // Yumuşak animasyon
        });

        // İçeriklerin sırayla görünmesini sağla
        gsap.from(".page-content", {
            opacity: 0,
            y: 50, // Yavaşça yukarı kayarak görünür hale gelmesi
            stagger: 0.2, // İçeriklerin sırayla görünmesi
            duration: 1.5, // Animasyon süresi
            ease: "power4.out",
        });
    } else {
        // Animasyon devre dışı bırakılmışsa, sayfa içeriğini doğrudan görünür yap
        console.log("Animasyonlar devre dışı bırakıldı.");
        document.body.style.opacity = "1"; // Opaklığı doğrudan 1 yap
    }
});
