<?php get_header(); ?>

<?php

	$title_switcher =  get_theme_mod('title_switch_404', 'on');
	$title =  get_theme_mod('title_404');

	$desc_switcher =  get_theme_mod('desc_switch_404', 'on');
	$desc =  get_theme_mod('desc_404');

	$button_switcher =  get_theme_mod('button_switch_404', 'on');
	$button =  get_theme_mod('button_404');
?>
<section class="main">
	<div class="container">
		<div class="blog-main">
			<div class="row">
				<div class="blog-posts page-main full-width col-md-12">
					<div class="row">
						<div class="page-not-found">
							<h4>404</h4>
							<?php if(true == get_theme_mod( 'title_switch_404', 'on' ) and !empty($title)) { ?>
								<span><?php echo esc_attr($title) ?></span>
							<?php } ?>
							<?php if(true == get_theme_mod( 'desc_switch_404', 'on' ) and !empty($desc)) { ?>
								<p><?php echo esc_attr($desc) ?></p>
							<?php } ?>
							<?php if(true == get_theme_mod( 'button_switch_404', 'on' ) and !empty($button)) { ?>
								<a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_attr($button) ?></a>
							<?php } ?>
						</div><!-- page-not-found -->
					</div><!-- row -->
				</div><!-- blog-posts -->
			</div><!-- row -->
		</div><!-- blog-main -->
	</div><!-- container -->
</section><!--main-->
<?php get_footer(); ?>
