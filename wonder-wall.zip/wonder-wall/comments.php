<?php
function linwall_post_single_comment_list($comment, $args, $depth){
?>
<li <?php comment_class('comment'); ?> id="comment-<?php comment_ID(); ?>">
        <div class="comment-user-image">
            <?php echo get_avatar($comment->comment_author_email , $args['avatar_size']); ?>
        </div>
        <div class="comment-info">
            <div class="comment-meta">
                <h4 class="author"><a href="<?php echo get_comment_link($comment->comment_ID); ?>"><?php echo $comment->comment_author ?></a><span></h4>
                <div class="reply-button">
                    <?php
                        comment_reply_link(
                            array_merge($args , array(
                                'depth' => $depth,
                                'max-depth' => $args['max_depth']
                            ))
                        );
                    ?>
                </div><!--reply-button-->
                <p><?php comment_text(); ?></p>

                <div class="comment-date">
                    <?php
                        $time_string = '<time class="entry-date published" itemprop="datePublished" datetime="%1$s">%2$s</time>';
                        $time_string = sprintf( $time_string,
                            esc_attr( get_comment_date( 'c' ) ),
                            esc_html( get_comment_date( 'M j, Y h:i A' ) ),
                        );
                        echo $time_string;
                    ?>
                </div><!--comment-date-->
            </div><!--comment-meta-->
        </div><!-- comment-info -->
<?php
}

?>
    <?php if ( have_comments() ) : ?>
        <div class="comments-post">
                     <ul class="comment-list">
                    <?php
                    wp_list_comments( array(
                    'short_ping'  => true,
                    'avatar_size' => 60,
                    'callback' => 'linwall_post_single_comment_list',
                    ));
                ?>
                </ul><!-- .comment-list -->

        </div><!-- #comment-post -->
    <?php endif; // have_comments() ?>

        <?php
        $commenter = wp_get_current_commenter();
        $req = get_option( 'require_name_email' );
        $aria_req = ( $req ? ' aria-required="true" data-required="true"' : '' );

        $args = array(
        'class_submit'			=> 'btn btn-default',
        'class_form'            =>  'comment-form',
        'title_reply_before'			=> '<div class="comment-respond-title"><h4>',
        'title_reply_after'			=>'</h4><span>' . esc_html__( 'Your email address will not be published. Required fields are marked *', 'linwall' ) . '</span></div>', 
        'comment_notes_before'	=> '',
        'comment_notes_after'	=> '',
        'cancel_reply_link'		=> ' <button type="button" class="btn btn-secondary">' .esc_html__('Cancel Reply', 'linwall') . '</button>',
        'label_submit'			=> esc_html__('Submit Comment', 'linwall'),

        'comment_field'			=> '<div class="col-sm-12"><div class="row">
                <p>
                    <label>Comment</label>
                    <textarea id="comment" name="comment" cols="15" rows="8" aria-required="true" class="form-control"></textarea>
                </p>
                </div></div>',

        'fields' => apply_filters( 'comment_form_default_fields', array(
                'author'		=>
                    '<div class="row"><div class="col-sm-6 col-xs-12">
                    <p class="comment-form-author">
                    <label>Name <span class="required"> *</span></label>
                        <input id="author" name="author" class="form-control" type="text" value="" size="30"' . $req . '">
                    </p>
                </div>',
                'email'		 	=>
                    '<div class="col-sm-6 col-xs-12">
                    <p class="comment-form-email">
                    <label>E-Mail <span class="required"> *</span></label>
                        <input id="email" name="email" class="form-control" type="email" value="" size="30"' . $req . '">
                    </p>
                    </div>',
                'url'		 	=>
                    '<div class="col-sm-12 col-xs-12">
                    <p class="comment-form-url">
                    <label>Web Site</label>
                        <input id="url" name="url" class="form-control" type="text" value="" size="30">
                    </p>
                </div>',

                '</div>'
            )
        ),
    );
    ?>

   <?php comment_form($args); ?>


<?php 
?>




