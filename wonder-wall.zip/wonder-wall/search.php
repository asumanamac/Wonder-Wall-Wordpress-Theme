<?php  
get_header();
?>

<?php
    global $query_string;
    $query_args = explode("&", $query_string);
    $search_query = array();

    foreach($query_args as $key => $string) {
      $query_split = explode("=", $string);
      $search_query[$query_split[0]] = urldecode($query_split[1]);
    } // foreach


    $column = get_theme_mod('column_archive');
    $column_space = get_theme_mod('column_space_archive');
    $button_text = get_theme_mod('button_archive');

    $the_query = new WP_Query($search_query);
    if ( $the_query->have_posts() ) {
    ?>
        <!-- the loop -->
        <div class="page-title">
            <div class="container">
                <div class="page-title-content">
                    <i class="fa fa-file-text-o"></i><h1><strong><?php wonder_wall_archive_title(); ?></strong></h1>
                </div><!--page-title-content-->
            </div><!--container-->
        </div><!--page-title-->
        <div class="container ">
            <div class="eb-blog-listing eb-style-1 eb-align-left">
                <div class="eb-blog-listing-inner">
                    <div class="row g-<?php echo esc_attr($column_space); ?>">
                        <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                            <?php if ( has_post_thumbnail()) {?>
                                <div class="col-md-<?php echo esc_attr($column); ?> col-sm-12">
                                    <div class="eb-item">
                                        <div class="eb-image">
                                            <a href="<?php get_permalink(get_the_ID()); ?>"><img src="<?php echo wp_get_attachment_image_src(get_post_thumbnail_id() , 'wonder-wall-blog1')[0] ?>"></a>
                                        </div><!--eb-image-->
                                        <div class="eb-content">
                                            <div class="eb-date">
                                                <a href="<?php echo get_permalink(); ?>">
                                                    <?php echo get_the_date(); ?>
                                                </a>
                                            </div>
                                            <div class="eb-title">
                                                 <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            </div><!--eb-title-->
                                            <div class="eb-button">
                                                <a href="<?php echo get_permalink(get_the_ID()) ?>">
                                                    <?php echo esc_attr($button_text); ?>
                                                </a>
                                            </div>
                                        </div><!--eb-content-->
                                    </div><!--eb-item-->
                                </div><!-- col-md-4 -->
                            <?php 
                            } 
                        endwhile;?>
                    </div><!--row-->
                </div><!--eb-blog-listing-inner-->
            </div><!--eb-blog-listing-->
        </div><!--container-->
        <div class="pagination">
            <?php wonder_wall_post_pagination();?>
        </div>
        <?php wp_reset_postdata(); ?>
     
    <?php }

    else {
        post_content_none();
     }
?>

<?php
get_footer();?>
