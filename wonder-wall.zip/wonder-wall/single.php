<?php 
get_header();

// Sayfa düzenini belirlemek için Customizer ve Meta Box kontrolü
$post_layout_customizer = get_theme_mod( 'wonder_wall_page_layout' );

if ( function_exists( 'rwmb_meta' ) ) {
    $post_layout = rwmb_meta( 'wonder-wall-page-layout' );
} else {
    $post_layout = '';
}

if ( ! empty( $post_layout ) ) {
    $post_layout_customizer = $post_layout;
}
?>

<!-- Swup kapsayıcısı -->
<div class="page-content">
    <div class="<?php echo ! empty( $post_layout_customizer ) ? esc_attr( $post_layout_customizer ) : 'default-container'; ?>">
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                the_content();
            }
        } else {
            echo '<p>' . esc_html__( 'No content found.', 'wonder-wall' ) . '</p>';
        }
        ?>
    </div>
</div>

<?php 
get_footer(); 
?>
