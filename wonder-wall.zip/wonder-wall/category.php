<?php  
get_header();
?>

<?php
    global $query_string;
    $query_args = explode("&", $query_string);
    $search_query = array();

    foreach($query_args as $key => $string) {
      $query_split = explode("=", $string);
      $search_query[$query_split[0]] = urldecode($query_split[1]);
    } // foreach

    $the_query = new WP_Query($search_query);
    if ( $the_query->have_posts() ) : 
    ?>
    <!-- the loop -->
    <section class="main">
        <div class="page-title">
            <div class="container">
                <div class="page-title-content">
                    <i class="fa fa-file-text-o"></i><h1>Browsing Category <strong>"<?php echo esc_attr(single_cat_title()); ?>"</strong></h1>

                </div><!--page-title-content-->
            </div><!--container-->
        </div><!--page-title-->
        <div class="container ">
            <div class="blog-main">
                <div class="row ">
                    <div class="blog-posts page-main col-md-9">
                        <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                            <?php if ( has_post_thumbnail()) {?>
                                <article class="post">
                                    <div class="row">
                                        <div class="col-md-3 post-type-image">
                                            <a href="<?php get_permalink(); ?>"><img src="<?php echo wp_get_attachment_image_src(get_post_thumbnail_id() , 'linwall-category-image')[0] ?>"></a>
                                        </div><!--post-type-image-->
                                        <div class="col-md-9 post-content">
                                            <header>
                                                <div class="post-category">
                                                    <ul>
                                                        <?php linwall_display_categories(); ?>
                                                    </ul>
                                                </div><!-- post-cat -->
                                                <div class="post-title">
                                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                                </div><!--post-title-->
                                                <div class="post-date">
                                                    <p><?php echo get_the_date(); ?></p>
                                                </div><!-- post-date -->
                                            </header>
                                            <div class="post-entry">
								                <p><?php echo wp_trim_words(get_the_content(), 30 , '.') ?></p>
                        	                </div><!--post-entry-->
                                        </div><!--col-md-9-->
                                    </div><!--row-->
                                </article><!-- post -->
                                <?php 
                            } 
                        endwhile;?>
                    </div><!--blog-post-->
                    <div class="sidebar col-md-3 col-sm-3">
                        <div class="sidebar-content">
                            <?php 
                            if (rwmb_meta('sidebar-general', '', get_the_ID()) == '') { 
                                dynamic_sidebar('sidebar-general');
                            }
                            else {
                                dynamic_sidebar('sidebar-general');
	                        }?>
                        </div><!--sidebar-content-->
                    </div><!--sidebar-->
                </div><!--row-->
            </div><!--blog-main-->
        </div><!--container-->
        <?php wp_reset_postdata(); ?>
        <?php linwall_post_pagination();?>
     </section>
    <?php endif; ?>


<?php
get_footer();?>
