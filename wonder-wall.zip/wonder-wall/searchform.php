<form method="get" role="search" class="eb-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="search" class="form-control search_input" autocomplete="off" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_html('Search', 'wonder-wall'); ?>">
	<button type="submit"><i class="fa fa-search"></i></button>
</form>